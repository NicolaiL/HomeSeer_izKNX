﻿Module EncodeDecode
    Function xBin2Float(stringdata As String) As Double
        Dim i As Integer

        Dim signed_part As String
        Dim exponent_part As String
        Dim floating_part As String

        Dim signed As Integer
        Dim exponent As Integer
        Dim float_digit As Integer

        Dim floating As Double
        Dim float_number As Double
        Dim float_factor As Double

        signed_part = Left$(stringdata, 1)
        exponent_part = Mid$(stringdata, 2, 8)
        floating_part = Right$(stringdata, 23)

        signed = xBin2Dec(signed_part)
        exponent = xBin2Dec(exponent_part)

        For i = 1 To 23
            float_digit = xBin2Dec(Mid$(floating_part, i, 1))
            If float_digit = 1 Then
                floating = float_digit / (2 ^ i)
                float_number = float_number + floating
            End If
        Next
        If exponent > 0 Then
            float_factor = 1 + float_number
        ElseIf exponent = 0 Then
            float_factor = float_number
        End If
        '
        ' Debug.Print signed
        ' Debug.Print exponent
        ' Debug.Print float_factor

        If exponent > 0 And exponent < 255 Then
            xBin2Float = ((-1) ^ signed) * (2 ^ (exponent - 127)) * float_factor
        ElseIf exponent = 0 Then
            xBin2Float = ((-1) ^ signed) * (2 ^ -126) * float_factor
        ElseIf exponent = 255 Then
            xBin2Float = 0
        End If

        Return xBin2Float

    End Function

    Function xBin2Dec(stringdata As String) As Long
        Dim n As Integer
        Dim a As Integer
        Dim x As String
        n = Len(stringdata) - 1
        a = n
        Do While n > -1
            x = Mid$(stringdata, ((a + 1) - n), 1)
            xBin2Dec = IIf((x = "1"), xBin2Dec + (2 ^ (n)), xBin2Dec)
            n = n - 1
        Loop

        Return xBin2Dec
    End Function

    Function KNXMantissaDecode(ByVal MSB As Byte, ByVal LSB As Byte) As Double
        'Dim MSB As Byte = Int(RawValue / 256)
        'Dim LSB As Byte = RawValue - MSB * 256

        Console.WriteLine("---START---")
        Console.WriteLine("Rawvalue: " & MSB.ToString & " " & LSB.ToString)
        Console.WriteLine("RawValue as binary: " & Convert.ToString(MSB, 2).PadLeft(8, "0"c) & " " & Convert.ToString(LSB, 2).PadLeft(8, "0"c))
        Console.WriteLine("RawValue as Hex: " & Convert.ToString(MSB, 16) & " " & Convert.ToString(LSB, 16))
        Console.WriteLine("MSB: " & MSB.ToString & "  LSB: " & LSB.ToString)

        Dim AllBits As String = Convert.ToString(MSB, 2).PadLeft(8, "0"c) & Convert.ToString(LSB, 2).PadLeft(8, "0"c)
        Dim PositiveSign As Boolean = Left(AllBits, 1) = "0"
        Dim ExponentString As String = Mid(AllBits, 2, 4)
        Dim Exponent As Byte = Convert.ToInt16(ExponentString, 2)
        Dim Mantissa As String = Right(AllBits, 11).PadRight(11 + Exponent, "0"c)

        Dim DecodedValue As Integer = 0
        Dim i As Integer = 0

        While Mantissa.Length > 0
            Dim TempMantissa As String = Right(Mantissa, Math.Min(8, Mantissa.Length)).PadLeft(8, "0"c)
            DecodedValue = DecodedValue + Convert.ToInt16(TempMantissa, 2) * (256 ^ i)
            i += 1
            If Mantissa.Length > 8 Then Mantissa = Left(Mantissa, Mantissa.Length - 8) Else Mantissa = ""
        End While

        If Not PositiveSign Then
            DecodedValue -= 1
            AllBits = Convert.ToString(DecodedValue, 2).PadLeft(11 + Exponent, "0"c)

            Dim TempStr() As Char = AllBits
            For i = 0 To TempStr.Length - 1
                If TempStr(i) = "0" Then TempStr(i) = "1" Else TempStr(i) = "0"
            Next
            i = 0
            Mantissa = TempStr
            DecodedValue = 0
            While Mantissa.Length > 0
                Dim TempMantissa As String = Right(Mantissa, Math.Min(8, Mantissa.Length)).PadLeft(8, "0"c)
                DecodedValue = DecodedValue + Convert.ToInt16(TempMantissa, 2) * (256 ^ i)
                i += 1
                If Mantissa.Length > 8 Then Mantissa = Left(Mantissa, Mantissa.Length - 8) Else Mantissa = ""
            End While

            DecodedValue = -DecodedValue
        End If

        Console.WriteLine("Decoded value: " & DecodedValue / 100)
        Console.WriteLine("---FINISH---")

        Return DecodedValue / 100
    End Function

    Function KNXMantissaEncode(ByVal Value As Double) As Byte()
        WriteLog(DebugLog, "=====START MANTISSA ENCODE=====", 5)
        If Value > 670760 Then
            WriteLog(ErrorLog, "Max. number sizxe for Mantissa encoding is 670,760. Current value is: " & Value, 0)
            Return Nothing
        End If
        If Value < -670760 Then
            WriteLog(ErrorLog, "Min. number sizxe for Mantissa encoding is -670,760. Current value is: " & Value, 0)
            Return Nothing
        End If
        WriteLog(DebugLog, "Value to encode: " & Value, 5)

        Dim Sign As Char = "0"
        If Value < 0 Then Sign = "1"

        Dim Mantissa As Double = Math.Abs(Value * 100)
        Dim Exponent As Byte = 0
        While Mantissa > 2047
            Mantissa = Int(Mantissa / 2)
            Exponent += 1
        End While

        Dim MantissaBin As String = Convert.ToString(CInt(Mantissa), 2).PadLeft(11, "0"c)
        Dim ExponentBin As String = Convert.ToString(Exponent, 2).PadLeft(4, "0"c)

        If Value < 0 Then
            Dim TempStr() As Char = MantissaBin
            For i = 0 To TempStr.Length - 1
                If TempStr(i) = "0" Then TempStr(i) = "1" Else TempStr(i) = "0"
            Next
            Mantissa = Convert.ToInt16(TempStr, 2) + 1
        End If

        MantissaBin = Convert.ToString(CInt(Mantissa), 2).PadLeft(11, "0"c)

        Dim EncodedString As String = Sign & ExponentBin & MantissaBin
        WriteLog(DebugLog, "Encoded String: " & Sign & " " & ExponentBin & " " & MantissaBin, 5)
        Dim MSBStr As String = Left(EncodedString, 8)
        Dim LSBStr As String = Right(EncodedString, 8)

        Dim EncodedValues(1) As Byte
        EncodedValues(0) = Convert.ToInt16(MSBStr, 2)
        EncodedValues(1) = Convert.ToInt16(LSBStr, 2)
        WriteLog(DebugLog, "Encoded values: " & Hex(EncodedValues(0)).PadLeft(2, "0"c) & " " & Hex(EncodedValues(1)).PadLeft(2, "0"c), 5)
        WriteLog(DebugLog, "=====FINISH MANTISSA ENCODE=====", 5)

        Return EncodedValues
    End Function
End Module
