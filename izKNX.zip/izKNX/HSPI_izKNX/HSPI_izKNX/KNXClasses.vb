﻿Public Enum enumDataPointTypes
    ' Number format: n.xxx or nn.xxx
    Not_Set = -9999
    ' DPT 1.xxx
    Switch = 1001
    [Boolean] = 1002

    ' DPT 3.xxx
    Dimming_Control = 3007
    Blind_Control = 3008

    ' DPT 5.xxx
    Scaling = 5001

    ' DPT 9.xxx
    Value_Temp = 9001
    Value_Lux = 9004

    ' DPT 12.x
    FourOctet_Unsigned = 12001

    ' DPT 18.xxx
    Scene_Control = 18001

    ' DPT 20.xxx
    HVAC_Mode = 20102

End Enum
Public Enum enumKNXActions ' Typically used in GroupAddress entries 
    Unknown = -9999
    Read = -10
    Write = -20

    Start_Stop_Dim = -30
    Start_Stop_Open_Close = -31

    Feedback = -50
    Feedback_On_Off = -51
    Feedback_Percentage = -52
    AbsoluteDim = -53
    Feedback_Value = -54
    Feedback_Position = -55

End Enum
Public Class DPTPairs
    Public Property Value As enumDataPointTypes
    Public Property Name As String

    Public Sub New()
        Value = enumDataPointTypes.Not_Set
        Name = ""
    End Sub
End Class
Public Enum enumRootActions
    Unknown = -9999

    Connect = -1001
    Disconnect = -1002

    Poll = -1003
    ' See also BusConnectionStatus for additional enums on this device
End Enum
Public Enum enumBinaryActions
    Unknown = -9999

    [On] = 1
    [Off] = 0
End Enum
Public Enum enumBinarySceneActions
    Unknown = -9999

    SceneOn = 1
    SceneOff = 0
End Enum
Public Enum enumSceneActions
    Unknown = -9999
End Enum
Public Enum enumDimmerActions
    Unknown = -9999

    [On] = 100
    [Off] = 0

    Start_Brighten = -10
    Start_Dimming = -11
    Stop_Dim_Action = -12

End Enum
Public Enum enumBlindCurtainActions
    Unknown = -9999

    Open = 1
    Close = 0

    Start_Opening = -10
    Start_Closing = -11
    Stop_OpenClose_Action = -12

End Enum
Public Enum enumMotionOccupancyActions
    Unknown = -9999

    Occupied = 1
    Not_Occupied = 0
End Enum
Public Enum enumTStatSetPointActions
    Unknown = -9999

    Increase = -100
    Decrease = -101
End Enum
Public Enum enumTStatHeatingValveActions
    Unknown = -9999

    Heat = 1
    [Off] = 0
End Enum
Public Enum enumTStatHVACModeActions
    Unknown = -9999

    [Next] = -1000
    Previous = -1001

    Auto = 0
    Comfort = 1
    Standby = 2
    Economy = 3
    Building_Protection = 4
End Enum
<Serializable()>
Public Class KNXGroupAddresPair
    Dim sGroupAddress As String
    Dim iAction As enumBinaryActions
    Dim sName As String
    Dim idvRef As Integer
    Dim iDPT As enumDataPointTypes
    Dim bPollMe As Boolean
    Public Property GroupAddress As String
        Get
            Return sGroupAddress
        End Get
        Set(value As String)
            sGroupAddress = value
        End Set
    End Property
    Public Property Action As enumBinaryActions
        Get
            Return iAction
        End Get
        Set(value As enumBinaryActions)
            iAction = value
        End Set
    End Property
    Public Property Name As String
        Get
            Return sName
        End Get
        Set(value As String)
            sName = value
        End Set
    End Property
    Public Property dvRef As Integer ' This property is only used in the GR Table
        Get
            Return idvRef
        End Get
        Set(value As Integer)
            idvRef = value
        End Set
    End Property
    Public Property DPT As enumDataPointTypes
        Get
            Return iDPT
        End Get
        Set(value As enumDataPointTypes)
            iDPT = value
        End Set
    End Property
    Public Property PollMe As Boolean
        Get
            Return bPollMe
        End Get
        Set(value As Boolean)
            bPollMe = value
        End Set
    End Property

    Public Sub New()
        dvRef = -1
        GroupAddress = ""
        Action = enumBinaryActions.Unknown
        Name = ""
        DPT = enumDataPointTypes.Not_Set
        PollMe = False
    End Sub
End Class


