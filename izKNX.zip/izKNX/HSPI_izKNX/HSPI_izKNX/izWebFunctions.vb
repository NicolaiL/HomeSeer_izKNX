﻿Imports System.Text
Imports Scheduler
Imports System.Web

'
' The Classes and Procedures/Functions are typically  used by ConfigDevice and ConfigDevicePost
'

Public Class ActionPairGAComparer
    Implements IEqualityComparer(Of KNXGroupAddresPair)

    Public Function Equals1(
        ByVal x As KNXGroupAddresPair,
        ByVal y As KNXGroupAddresPair
        ) As Boolean Implements IEqualityComparer(Of KNXGroupAddresPair).Equals

        ' Check whether the compared objects reference the same data.
        If x.GroupAddress = "" Or y.GroupAddress = "" Then Return False ' Ignore blank entries 
        If x.GroupAddress.Trim.ToLower = y.GroupAddress.Trim.ToLower Then Return True Else Return False

    End Function

    Public Function GetHashCode1(
        ByVal product As KNXGroupAddresPair
        ) As Integer Implements IEqualityComparer(Of KNXGroupAddresPair).GetHashCode
        Return Nothing
    End Function

End Class
Module izWebFunctions
#Region "WebPage Stuff"
    Friend Function GroupActionPairHeader(ByVal Title As String) As String
        Dim stb As New StringBuilder

        stb.Append("<form id='frmKNX' name='KNXTab' method='Post'>")

        stb.Append(clsPageBuilder.DivStart("CPmessage", "class='errormessage'"))
        stb.Append(clsPageBuilder.DivEnd)

        stb.Append(" <table border='0' cellpadding='0' cellspacing='0' width='610'>")

        stb.Append("<tr><td colspan='4' align='Left' style='font-size:12pt; height:30px;' nowrap><b>" & Title & "</b></td></tr>")

        stb.Append("<table border='1' cellpadding='1' cellspacing='0'>")
        stb.Append("<tr>")
        stb.Append("<td class='tablecolumn' width='200'>Name:</td>")
        stb.Append("<td class='tablecolumn' width='200'>Group Address:</td>")
        stb.Append("<td class='tablecolumn' width='200'>Action:</td>")
        stb.Append("<td class='tablecolumn' width='200'>Data Point Type:</td>")
        stb.Append("<td class='tablecolumn' width='100'>Polling:</td>")
        stb.Append("<td class='tablecolumn' width='100'></td>")
        stb.Append("</tr>")

        Return stb.ToString
    End Function
    Friend Function GroupActionPairFooter() As String
        Dim stb As New StringBuilder

        stb.Append("</table>")
        stb.Append("<br>")

        Dim bSave As New clsJQuery.jqButton("Save", "Save", "DeviceUtility", True)
        stb.Append(bSave.Build)

        Dim bAdd As New clsJQuery.jqButton("Additional", "Additional Entry", "DeviceUtility", True)
        stb.Append(bAdd.Build)

        stb.Append("</form>")
        Return stb.ToString
    End Function
    Friend Function BuildSingleActionPair(ByVal ThisPair As KNXGroupAddresPair, ByVal Idx As Integer) As String         ' Optional ByVal ChosenOne As Integer = -1
        Dim stb As New StringBuilder
        'Dim jqTB As New clsJQuery.jqTextBox = 
        '
        stb.Append("<tr>")

        stb.Append("<td>")
        Dim NameBox As New clsJQuery.jqTextBox("Name" & Idx, "", ThisPair.Name.ToString, "abc", 20, False)
        NameBox.promptText = "Enter Friendly name for this device/action"
        stb.Append(NameBox.Build)
        stb.Append("</td>")

        stb.Append("<td>")
        Dim GABox As New clsJQuery.jqTextBox("GroupAddress" & Idx, "", ThisPair.GroupAddress.ToString, "abc", 20, False)
        GABox.promptText = "Enter the KNX Group Address for this device/action"
        stb.Append(GABox.Build)
        stb.Append("</td>")

        stb.Append("<td>")
        ' Action
        Dim dl As New clsJQuery.jqDropList("Action" & Idx, "", False)
        Dim dlString As String = ""
        dl.items = ActionPairTable
        dl.id = "Action" & Idx
        Dim i As Integer = 0
        For Each Entry In ActionPairTable
            If Val(Entry.Value) = ThisPair.Action Then
                dl.selectedItemIndex = i
                Exit For
            End If
            i += 1
        Next
        dlString = dl.Build
        stb.Append(dlString)
        stb.Append("</td>")

        stb.Append("<td>")
        ' DPT
        dl = New clsJQuery.jqDropList("DPT" & Idx, "", False)
        dlString = ""
        dl.items = DataPointTypeTable
        dl.id = "DPT" & Idx
        i = 0
        For Each Entry In DataPointTypeTable
            If Val(Entry.Value) = ThisPair.DPT Then
                dl.selectedItemIndex = i
                Exit For
            End If
            i += 1
        Next
        dlString = dl.Build
        stb.Append(dlString)
        stb.Append("</td>")

        stb.Append("<td>")
        Dim cb As New clsJQuery.jqCheckBox("Poll" & Idx, "", "DeviceUtility", True, False)
        cb.id = "oPoll" & Idx
        cb.checked = ThisPair.PollMe
        cb.LabelOnLeft = True
        cb.sliderStyle = True
        stb.Append(cb.Build)
        stb.Append("</td>")


        stb.Append("<td>")
        Dim bDelete As New clsJQuery.jqButton("Delete" & Idx, "Delete", "DeviceUtility", True)
        stb.Append(bDelete.Build())
        stb.Append("</td>")

        stb.Append("</tr>")

        Return stb.ToString
    End Function
    Friend Function ExtractActionPairs(ByVal CurrentRef As Integer, ByVal Data As String) As List(Of KNXGroupAddresPair)
        Dim parts As Collections.Specialized.NameValueCollection
        Dim PairCount As Integer = 4 'CurrentPair.Length
        Dim Pairs As New List(Of KNXGroupAddresPair)
        Dim SinglePair As New KNXGroupAddresPair

        parts = HttpUtility.ParseQueryString(Data)

        For Each key In parts.AllKeys
            If Left(key, 12) = "GroupAddress" Then
                Dim Idx As Integer = Val(Right(key, key.Length - 12))
                SinglePair = New KNXGroupAddresPair
                SinglePair.GroupAddress = parts("GroupAddress" & Idx.ToString).Trim
                SinglePair.dvRef = CurrentRef
                SinglePair.Action = parts("Action" & Idx.ToString).Trim
                SinglePair.DPT = parts("DPT" & Idx.ToString).Trim
                SinglePair.Name = parts("Name" & Idx.ToString).Trim
                Dim tt As String = parts("Poll" & Idx.ToString)
                If parts("Poll" & Idx.ToString).Trim.ToLower = "checked" Then
                    SinglePair.PollMe = True
                Else
                    SinglePair.PollMe = False
                End If
                Pairs.Add(SinglePair)
            End If
        Next

        Return Pairs
    End Function
#End Region

End Module
