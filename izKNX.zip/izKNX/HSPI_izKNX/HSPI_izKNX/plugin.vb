﻿Imports System.Text
Imports System.Web
Imports HomeSeerAPI
Imports Scheduler

Public Class plugin
    Dim sConfigPage As String = "izKNX_Config"
    Dim sStatusPage As String = "izKNX_Status"
    Dim sHelpPage As String = "http://home.indigozest.net/FTP/HomeSeer3/izKNX/izKNX_manual.pdf"

    Dim ConfigPage As New web_config(sConfigPage)
    Dim StatusPage As New web_status(sStatusPage)
    Dim WebPage As Object

    Dim actions As New hsCollection
    Dim action As New action
    Dim triggers As New hsCollection
    Dim trigger As New trigger

    Dim Commands As New hsCollection

    Const Pagename = "Events"

#Region "Action/Trigger/Device Processes"
#Region "Device Interface"

    Public Function ConfigDevice(ref As Integer, user As String, userRights As Integer, newDevice As Boolean) As String
        Try
            Dim dv As Scheduler.Classes.DeviceClass = Nothing
            dv = hs.GetDeviceByRef(ref)

            Dim DeviceType As String = dv.Device_Type_String(Nothing)
            DeviceType = Right(DeviceType, DeviceType.Length - IFACE_NAME.Length)

            'If DeviceType = TypeKNXRoot Then Return "" ' Nothing to configure on this device
            If InStr(DeviceType.ToLower, "root") Then Return "" ' Nothing to configure on "true" root devices

            Dim PED As clsPlugExtraData = dv.PlugExtraData_Get(hs)
            Dim PEDObject As New Object

            Dim KNXPairList As New List(Of KNXGroupAddresPair)
            KNXPairList = PEDGet(PED, PEDName)
            If KNXPairList Is Nothing Then
                KNXPairList = New List(Of KNXGroupAddresPair)
                Select Case DeviceType
                    Case TypeBinary
                        KNXPairList = InitiateLightBinaryList(ref)
                    Case TypeDimmer
                        KNXPairList = InitiateLightDimmerList(ref)
                    Case TypeTemperature
                        KNXPairList = InitiateTemperatureSensorList(ref)
                    Case TypeMotionOccupancy
                        KNXPairList = InitiateMotionOccupancyList(ref)
                    Case TypeLuxLevel
                        KNXPairList = InitiateLuxLevelList(ref)
                    Case TypeBlindCurtain
                        KNXPairList = InitiateBlindCurtainList(ref)
                    Case TypeBinaryScene
                        KNXPairList = InitiateBinarySceneList(ref)
                    Case TypeScene
                        KNXPairList = InitiateSceneList(ref)
                    Case TypeTStatSetPoint
                        KNXPairList = InitiateTStatSetpointList()
                    Case TypeTStatTemperature
                        KNXPairList = InitiateTStatTemperatureList()
                    Case TypeTStatHeatingValve
                        KNXPairList = InitiateTStatHeatingValveList()
                    Case TypeTStatHVACMode
                        KNXPairList = InitiateTStatHVACModeList()
                    Case Else
                        ' No action, KNXPairList already initiated
                End Select
                PEDAdd(PED, PEDName, KNXPairList)
                dv.PlugExtraData_Set(hs) = PED
            End If

            Dim stb As New StringBuilder
            stb.Append(GroupActionPairHeader("Enter Group Addresses for each Action:"))
            Dim i As Integer = 0
            For Each Entry In KNXPairList
                stb.Append(BuildSingleActionPair(Entry, i))
                i += 1
            Next

            stb.Append(GroupActionPairFooter)
            Return stb.ToString
        Catch ex As Exception
            WriteLog(ErrorLog, ex.Message, 0)
            Return Err.Description
        End Try
    End Function

    Public Function ConfigDevicePost(ref As Integer, data As String, user As String, userRights As Integer) As Enums.ConfigDevicePostReturn

        Dim parts As Collections.Specialized.NameValueCollection
            parts = HttpUtility.ParseQueryString(data)

        Select Case Left(parts("id"), 4)
            Case "Save"
                Try
                    Dim dv As Scheduler.Classes.DeviceClass = Nothing

                    Dim PED As New clsPlugExtraData
                    Dim ReturnValue As Integer = Enums.ConfigDevicePostReturn.DoneAndCancel
                    Dim PEDObject As New Object

                    dv = hs.GetDeviceByRef(ref)

                    Dim ActionPairs As New List(Of KNXGroupAddresPair)
                    ActionPairs = ExtractActionPairs(ref, data)

                    ' Check data are OK before saving, otherwise exit out
                    ' Check no GroupAddress is used twice
                    Dim NoDuplicates = ActionPairs.Distinct(New ActionPairGAComparer)
                    If NoDuplicates.Count <> ActionPairs.Count Then
                        ' We have duplicate GroupAddresses
                        callback.ConfigDivToUpdateAdd("CPmessage", "Error: Duplicate GroupAddress entries exists")
                        WriteLog(ErrorLog, "Can't save izKNX page. Duplicate GroupAddress entries exists", 0)
                        Return Enums.ConfigDevicePostReturn.DoneAndCancelAndStay
                    End If

                    ' Check Polling is only switched on for max one device
                    Dim PollExist As Boolean = False
                    Dim PollCount As Integer = 0
                    For Each Pair In ActionPairs
                        If Pair.PollMe = True Then
                            PollExist = True
                            PollCount += 1
                        End If
                    Next
                    If PollCount > 1 Then
                        ' Exit as you can only have max One poll per HS3 device
                        callback.ConfigDivToUpdateAdd("CPmessage", "Error: Polling can only be setup on one GroupAddress entry per device")
                        WriteLog(ErrorLog, "Can't save izKNX page. Polling can only be setup on one GroupAddress entry per device", 0)
                        Return Enums.ConfigDevicePostReturn.DoneAndCancelAndStay
                    End If

                    ' Check Group Addresses are in a correct structure for the type chosen
                    Dim RtnMsg As String = ""
                    For Each Pair In ActionPairs
                        If Pair.GroupAddress <> "" Then
                            RtnMsg = ValidateGroupAddress(Pair.GroupAddress)
                            If RtnMsg <> "" Then
                                callback.ConfigDivToUpdateAdd("CPmessage", RtnMsg)
                                WriteLog(ErrorLog, "Can't save izKNX page. " & RtnMsg, 0)
                                Return Enums.ConfigDevicePostReturn.DoneAndCancelAndStay
                            End If
                        End If
                    Next

                    PEDAdd(PED, PEDName, ActionPairs)
                    dv.PlugExtraData_Set(hs) = PED
                    hs.SaveEventsDevices()

                    If PollExist Then
                        Dim ExistingReadVS As VSPair = hs.DeviceVSP_Get(ref, enumRootActions.Poll, ePairStatusControl.Control)
                        If ExistingReadVS Is Nothing Then
                            Dim TotalCAPIButton As Integer = hs.DeviceVSP_CountControl(ref)
                            Dim Row As Integer = Int(TotalCAPIButton / 3) + 1
                            Dim Col As Integer = TotalCAPIButton - (Row - 1) * 3 + 1
                            AddVSPairs(ref, ePairStatusControl.Control, enumRootActions.Poll, enumRootActions.Poll.ToString, Row, Col)
                        End If
                    Else
                        Dim ExistingReadVS As VSPair = hs.DeviceVSP_Get(ref, enumRootActions.Poll, ePairStatusControl.Control)
                        If ExistingReadVS IsNot Nothing Then
                            hs.DeviceVSP_ClearControl(ref, enumRootActions.Poll)
                        End If
                    End If

                    If _RebuildOnSave Then GroupAddressTable = BuildGATable()

                    callback.ConfigDivToUpdateAdd("CPmessage", "")
                    Return Enums.ConfigDevicePostReturn.DoneAndSave
                Catch ex As Exception
                    WriteLog(ErrorLog, "Error saving PED. Messsage: " & ex.Message, 0)
                    callback.ConfigDivToUpdateAdd("CPmessage", "")
                    Return Enums.ConfigDevicePostReturn.DoneAndCancel
                End Try
            Case "Dele"
                Dim Idx As Integer = Val(Right(parts("id"), parts("id").Length - "Delete".Length))

                Dim dv As Scheduler.Classes.DeviceClass = Nothing

                Dim PED As New clsPlugExtraData
                Dim ReturnValue As Integer = Enums.ConfigDevicePostReturn.DoneAndCancel
                Dim PEDObject As New Object

                dv = hs.GetDeviceByRef(ref)

                Dim ActionPairs As New List(Of KNXGroupAddresPair)
                ActionPairs = ExtractActionPairs(ref, data)
                ActionPairs.RemoveAt(Idx) '  Remove the entry With Index IDX

                PEDAdd(PED, PEDName, ActionPairs)

                dv.PlugExtraData_Set(hs) = PED
                hs.SaveEventsDevices()

                callback.ConfigDivToUpdateAdd("CPmessage", "")
                Return Enums.ConfigDevicePostReturn.CallbackOnce
            Case "Addi"
                Dim dv As Scheduler.Classes.DeviceClass = Nothing

                Dim PED As New clsPlugExtraData
                Dim ReturnValue As Integer = Enums.ConfigDevicePostReturn.DoneAndCancel
                Dim PEDObject As New Object

                dv = hs.GetDeviceByRef(ref)

                Dim ActionPairs As New List(Of KNXGroupAddresPair)
                ActionPairs = ExtractActionPairs(ref, data)

                Dim NewPair As New KNXGroupAddresPair
                NewPair.Name = "Change Me"
                NewPair.Action = enumKNXActions.Unknown
                NewPair.DPT = enumDataPointTypes.Not_Set
                NewPair.GroupAddress = ""
                ActionPairs.Add(NewPair)

                PEDAdd(PED, PEDName, ActionPairs)

                dv.PlugExtraData_Set(hs) = PED
                hs.SaveEventsDevices()

                callback.ConfigDivToUpdateAdd("CPmessage", "")
                Return Enums.ConfigDevicePostReturn.CallbackOnce
        End Select

        callback.ConfigDivToUpdateAdd("CPmessage", "")
        Return Enums.ConfigDevicePostReturn.DoneAndCancel
    End Function

    Public Sub SetIOMulti(colSend As System.Collections.Generic.List(Of HomeSeerAPI.CAPI.CAPIControl))

        Dim CC As CAPIControl
        Dim dv As Scheduler.Classes.DeviceClass = Nothing

        For Each CC In colSend
            dv = hs.GetDeviceByRef(CC.Ref)
            Dim dvRef As Integer = CC.Ref
            Dim AdrLookup As String = dv.Address(Nothing)
            AdrLookup = Right(AdrLookup, Len(AdrLookup) - InStr(AdrLookup, "-") + 1)

            Dim KNXGroupAddress As String = ""

            Select Case AdrLookup
                Case SuffixKNXRoot
                    Select Case CC.ControlValue
                        Case enumRootActions.Connect
                            KNXSetupConnection()
                        Case enumRootActions.Disconnect
                            KNXCloseConnection()
                        Case Else
                            InvalidControlValue(dv.Ref(Nothing), AdrLookup, CC.ControlValue)
                    End Select

                Case SuffixBinary
                    Select Case CC.ControlValue
                        Case enumBinaryActions.On, enumBinaryActions.Off
                            KNXGroupAddress = FindDeviceGroupAddress(dvRef, enumKNXActions.Write)
                            Dim KNXDPT As Integer = FindDeviceGADPT(dvRef, KNXGroupAddress)
                            EncodeAndSend(KNXGroupAddress, CC.ControlValue, KNXDPT)
                        Case enumRootActions.Poll
                            KNXPollDevice(dvRef, False)
                        Case Else
                            InvalidControlValue(dv.Ref(Nothing), AdrLookup, CC.ControlValue)
                    End Select

                Case SuffixDimmer
                    Select Case CC.ControlValue
                        Case enumDimmerActions.On, enumDimmerActions.Off
                            Dim Command As Boolean = CC.ControlValue = enumDimmerActions.On
                            KNXGroupAddress = FindDeviceGroupAddress(dvRef, enumKNXActions.Write)
                            If KNXGroupAddress <> "" Then KNXSendBoolean(KNXGroupAddress, Command) Else WriteLog(WarningLog, "GroupMessage not setup for device", 0)
                        Case 1 To 99 ' Absolute Dim Value
                            KNXGroupAddress = FindDeviceGroupAddress(dvRef, enumKNXActions.AbsoluteDim)
                            If KNXGroupAddress <> "" Then KNXSendByte(KNXGroupAddress, EncodeDimValue(CC.ControlValue)) Else WriteLog(WarningLog, "GroupMessage not setup for device", 0)
                        Case enumDimmerActions.Start_Brighten, enumDimmerActions.Start_Dimming ' Start/Stop Dim
                            KNXGroupAddress = FindDeviceGroupAddress(dvRef, enumKNXActions.Start_Stop_Dim)
                            If KNXGroupAddress <> "" Then KNXSend4Bit(KNXGroupAddress, EncodeDimStep(CC.ControlValue = enumDimmerActions.Start_Brighten)) Else WriteLog(WarningLog, "GroupMessage not setup for device", 0)
                        Case enumDimmerActions.Stop_Dim_Action
                            KNXGroupAddress = FindDeviceGroupAddress(dvRef, enumKNXActions.Start_Stop_Dim)
                            If KNXGroupAddress <> "" Then KNXSend4Bit(KNXGroupAddress, 0) Else WriteLog(WarningLog, "GroupMessage not setup for device", 0)
                        Case enumRootActions.Poll
                            KNXPollDevice(dvRef, False)
                        Case Else
                            InvalidControlValue(dv.Ref(Nothing), AdrLookup, CC.ControlValue)
                    End Select

                Case SuffixBlindCurtain
                    Select Case CC.ControlValue
                        Case enumBlindCurtainActions.Open, enumBlindCurtainActions.Close
                            Dim Command As Boolean = CC.ControlValue = enumBlindCurtainActions.Open
                            KNXGroupAddress = FindDeviceGroupAddress(dvRef, enumKNXActions.Write)
                            If KNXGroupAddress <> "" Then KNXSendBoolean(KNXGroupAddress, Command) Else WriteLog(WarningLog, "GroupMessage not setup for device", 0)
                        Case enumBlindCurtainActions.Start_Opening, enumBlindCurtainActions.Start_Closing
                            Dim Command As Boolean = CC.ControlValue = enumBlindCurtainActions.Start_Opening
                            KNXGroupAddress = FindDeviceGroupAddress(dvRef, enumKNXActions.Start_Stop_Open_Close)
                            If KNXGroupAddress <> "" Then KNXSendBoolean(KNXGroupAddress, Command) Else WriteLog(WarningLog, "GroupMessage not setup for device", 0)
                        Case enumRootActions.Poll
                            KNXPollDevice(dvRef, False)
                        Case Else
                            InvalidControlValue(dv.Ref(Nothing), AdrLookup, CC.ControlValue)
                    End Select

                Case SuffixLuxLevel
                    Select Case CC.ControlValue
                        Case enumRootActions.Poll
                            KNXPollDevice(dvRef, False)
                        Case Else
                            InvalidControlValue(dv.Ref(Nothing), AdrLookup, CC.ControlValue)
                    End Select

                Case SuffixMotionOccupancy
                    Select Case CC.ControlValue
                        Case enumRootActions.Poll
                            KNXPollDevice(dvRef, False)
                        Case Else
                            InvalidControlValue(dv.Ref(Nothing), AdrLookup, CC.ControlValue)
                    End Select

                Case SuffixTemperatureSensor
                    Select Case CC.ControlValue
                        Case enumRootActions.Poll
                            KNXPollDevice(dvRef, False)
                        Case Else
                            InvalidControlValue(dv.Ref(Nothing), AdrLookup, CC.ControlValue)
                    End Select

                Case SuffixBinaryScene
                    Select Case CC.ControlValue
                        Case enumBinarySceneActions.SceneOn, enumBinarySceneActions.SceneOff
                            Dim Command As Boolean = CC.ControlValue = enumBinarySceneActions.SceneOn
                            KNXGroupAddress = FindDeviceGroupAddress(dvRef, enumKNXActions.Write)
                            If KNXGroupAddress <> "" Then KNXSendBoolean(KNXGroupAddress, Command) Else WriteLog(WarningLog, "GroupMessage not setup for device", 0)
                        Case enumRootActions.Poll
                            KNXPollDevice(dvRef, False)
                        Case Else
                            InvalidControlValue(dv.Ref(Nothing), AdrLookup, CC.ControlValue)
                    End Select

                Case SuffixScene
                    Select Case CC.ControlValue
                        Case 1 To 64
                            KNXGroupAddress = FindDeviceGroupAddress(dvRef, enumKNXActions.Write)
                            If KNXGroupAddress <> "" Then KNXSendByte(KNXGroupAddress, EncodeSceneValue(CC.ControlValue, True))
                        Case -64 To -1
                            KNXGroupAddress = FindDeviceGroupAddress(dvRef, enumKNXActions.Write)
                            If KNXGroupAddress <> "" Then KNXSendByte(KNXGroupAddress, EncodeSceneValue(CC.ControlValue, False))
                        Case Else
                            InvalidControlValue(dv.Ref(Nothing), AdrLookup, CC.ControlValue)
                    End Select

                Case SuffixTStatTemperature
                    Select Case CC.ControlValue
                        Case enumRootActions.Poll
                            KNXPollDevice(dvRef, False)
                        Case Else
                            InvalidControlValue(dv.Ref(Nothing), AdrLookup, CC.ControlValue)
                    End Select

                Case SuffixTStatSetPoint
                    Select Case CC.ControlValue
                        Case enumRootActions.Poll
                            KNXPollDevice(dvRef, False)
                        Case enumTStatSetPointActions.Increase, enumTStatSetPointActions.Decrease, -50 To 50
                            Dim NewSetPoint As Integer = 0
                            Dim CurrentSetPoint As Integer = hs.DeviceValue(CC.Ref)
                            Select Case CC.ControlValue
                                Case enumTStatSetPointActions.Increase
                                    NewSetPoint = CurrentSetPoint + 1
                                Case enumTStatSetPointActions.Decrease
                                    NewSetPoint = CurrentSetPoint - 1
                                Case Else
                                    NewSetPoint = CC.ControlValue
                            End Select
                            KNXGroupAddress = FindDeviceGroupAddress(dvRef, enumKNXActions.Write)

                            If KNXGroupAddress <> "" Then
                                Dim KNXDPT As Integer = FindDeviceGADPT(dvRef, KNXGroupAddress)
                                EncodeAndSend(KNXGroupAddress, NewSetPoint, KNXDPT)
                                'KNXSendDoubleByte(KNXGroupAddress, KNXMantissaEncode(NewSetPoint))
                            End If
                        Case Else
                            InvalidControlValue(dv.Ref(Nothing), AdrLookup, CC.ControlValue)
                    End Select

                Case SuffixTStatHVACMode
                    Select Case CC.ControlValue
                        Case enumRootActions.Poll
                            KNXPollDevice(dvRef, False)
                        Case enumTStatHVACModeActions.Next, enumTStatHVACModeActions.Previous, enumTStatHVACModeActions.Auto,
                             enumTStatHVACModeActions.Comfort, enumTStatHVACModeActions.Standby, enumTStatHVACModeActions.Economy,
                             enumTStatHVACModeActions.Building_Protection
                            Dim NewHVACMode As Integer = -1
                            Dim CurrentHVACMode As Integer = hs.DeviceValue(CC.Ref)
                            Select Case CC.ControlValue
                                Case enumTStatHVACModeActions.Next
                                    NewHVACMode = CurrentHVACMode + 1
                                Case enumTStatHVACModeActions.Previous
                                    NewHVACMode = CurrentHVACMode - 1
                                Case Else
                                    NewHVACMode = CC.ControlValue
                            End Select
                            If NewHVACMode < enumTStatHVACModeActions.Auto Then NewHVACMode = enumTStatHVACModeActions.Auto
                            If NewHVACMode > enumTStatHVACModeActions.Building_Protection Then NewHVACMode = enumTStatHVACModeActions.Building_Protection
                            KNXGroupAddress = FindDeviceGroupAddress(dvRef, enumKNXActions.Write)
                            If KNXGroupAddress <> "" Then
                                Dim KNXDPT As Integer = FindDeviceGADPT(dvRef, KNXGroupAddress)
                                EncodeAndSend(KNXGroupAddress, NewHVACMode, KNXDPT)
                            End If
                        Case Else
                            InvalidControlValue(dv.Ref(Nothing), AdrLookup, CC.ControlValue)
                    End Select


            End Select
        Next
    End Sub

#End Region

#Region "Action Properties"

    Sub SetActions()
        Dim o As Object = Nothing
        '  If actions.Count = 0 Then
        '  actions.Add(o, "Send Command")
        '  End If
    End Sub

    Function ActionCount() As Integer
        ' SetActions()
        ' Return actions.Count
        Return 0
    End Function

    ReadOnly Property ActionName(ByVal ActionNumber As Integer) As String
        Get
            SetActions()
            If ActionNumber > 0 AndAlso ActionNumber <= actions.Count Then
                Return IFACE_NAME & ": " & actions.Keys(ActionNumber - 1)
            Else
                Return ""
            End If
        End Get
    End Property

    Function ActionReferencesDevice(ByVal ActInfo As IPlugInAPI.strTrigActInfo, ByVal dvRef As Integer) As Boolean

        hs.WriteLog("HELP!!", "In ActionReferencesDevice")
        Console.WriteLine("HELP!!  -  In ActionReferencesDevice")
        'Dim Act As MyAct = Nothing
        'Try
        'Act = GetAction(ActInfo)
        'Catch ex As Exception
        'Act = Nothing
        'End Try
        'If Act Is Nothing Then Return False
        'Return Act.Devices.Contains(dvRef)
        Return False
    End Function

#End Region

#Region "Trigger Proerties"

    Sub SetTriggers()
        'Dim o As Object = Nothing
        'If triggers.Count = 0 Then
        ' triggers.Add(o, "Recieve Command")
        ' End If
    End Sub

    Public ReadOnly Property HasTriggers() As Boolean
        Get
            '    SetTriggers()
            '    Return IIf(triggers.Count > 0, True, False)
            Return False
        End Get
    End Property

    Public Function TriggerCount() As Integer
        'SetTriggers()
        'Return triggers.Count
        Return 0
    End Function

    Public ReadOnly Property SubTriggerCount(ByVal TriggerNumber As Integer) As Integer
        Get
            '    Dim trigger As trigger
            '    If ValidTrig(TriggerNumber) Then
            '        trigger = triggers(TriggerNumber - 1)
            '        If Not (trigger Is Nothing) Then
            '            Return trigger.Count
            '        Else
            '            Return 0
            '        End If
            '    Else
            Return 0
            '    End If
        End Get
    End Property

    Public ReadOnly Property TriggerName(ByVal TriggerNumber As Integer) As String
        Get
            'If Not ValidTrig(TriggerNumber) Then
            Return ""
            'Else
            'Return IFACE_NAME & ": " & triggers.Keys(TriggerNumber - 1)
            'End If
        End Get
    End Property

    Public ReadOnly Property SubTriggerName(ByVal TriggerNumber As Integer, ByVal SubTriggerNumber As Integer) As String
        Get
            'Dim trigger As trigger
            'If ValidSubTrig(TriggerNumber, SubTriggerNumber) Then
            ' trigger = triggers(TriggerNumber)
            ' Return IFACE_NAME & ": " & trigger.Keys(SubTriggerNumber)
            ' Else
            Return ""
            'End If
        End Get
    End Property

    Friend Function ValidTrig(ByVal TrigIn As Integer) As Boolean
        SetTriggers()
        'If TrigIn > 0 AndAlso TrigIn <= triggers.Count Then
        '    Return True
        'End If
        Return False
    End Function

    Public Function ValidSubTrig(ByVal TrigIn As Integer, ByVal SubTrigIn As Integer) As Boolean
        'Dim trigger As trigger = Nothing
        'If TrigIn > 0 AndAlso TrigIn <= triggers.Count Then
        ' trigger = triggers(TrigIn)
        ' If Not (trigger Is Nothing) Then
        ' If SubTrigIn > 0 AndAlso SubTrigIn <= trigger.Count Then Return True
        ' End If
        ' End If
        Return False
    End Function

#End Region

#Region "Action Interface"

    Public Function HandleAction(ByVal ActInfo As IPlugInAPI.strTrigActInfo) As Boolean
        Dim Housecode As String = ""
        Dim DeviceCode As String = ""
        Dim Command As String = ""
        Dim UID As String
        UID = ActInfo.UID.ToString

        Try
            If Not (ActInfo.DataIn Is Nothing) Then
                DeSerializeObject(ActInfo.DataIn, action)
            Else
                Return False
            End If
            For Each sKey In action.Keys
                Select Case True
                    Case InStr(sKey, "Housecodes_" & UID) > 0
                        Housecode = action(sKey)
                    Case InStr(sKey, "DeviceCodes_" & UID) > 0
                        DeviceCode = action(sKey)
                    Case InStr(sKey, "Commands_" & UID) > 0
                        Command = action(sKey)
                End Select
            Next

            'SendCommand(Housecode, DeviceCode, Command)

        Catch ex As Exception
            hs.WriteLog(IFACE_NAME, "Error executing action: " & ex.Message)
        End Try
        Return True
    End Function

    Public Function ActionConfigured(ByVal ActInfo As IPlugInAPI.strTrigActInfo) As Boolean
        Dim Configured As Boolean = False
        Dim sKey As String
        Dim itemsConfigured As Integer = 0
        Dim itemsToConfigure As Integer = 3
        Dim UID As String
        UID = ActInfo.UID.ToString

        If Not (ActInfo.DataIn Is Nothing) Then
            DeSerializeObject(ActInfo.DataIn, action)
            For Each sKey In action.Keys
                Select Case True
                    Case InStr(sKey, "Housecodes_" & UID) > 0 AndAlso action(sKey) <> ""
                        itemsConfigured += 1
                    Case InStr(sKey, "DeviceCodes_" & UID) > 0 AndAlso action(sKey) <> ""
                        itemsConfigured += 1
                    Case InStr(sKey, "Commands_" & UID) > 0 AndAlso action(sKey) <> ""
                        itemsConfigured += 1
                End Select
            Next
            If itemsConfigured = itemsToConfigure Then Configured = True
        End If
        Return Configured
    End Function

    Public Function ActionBuildUI(ByVal sUnique As String, ByVal ActInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As String
        Dim UID As String
        UID = ActInfo.UID.ToString
        Dim stb As New StringBuilder

        Dim Group As String = ""
        Dim Colour As String = ""
        Dim Program As String = ""
        Dim Value As String = ""

        'Dim Housecode As String = ""
        'Dim DeviceCode As String = ""
        'Dim Command As String = ""

        Dim dd1 As New clsJQuery.jqDropList("Group_" & UID & sUnique, Pagename, True)
        dd1.autoPostBack = True
        dd1.AddItem("--Please Select--", "", False)

        Dim dd2 As New clsJQuery.jqDropList("Colour_" & UID & sUnique, Pagename, True)
        dd2.autoPostBack = True
        dd2.AddItem("--Please Select--", "", False)

        Dim dd3 As New clsJQuery.jqDropList("Program_" & UID & sUnique, Pagename, True)
        dd3.autoPostBack = True
        dd3.AddItem("--Please Select--", "", False)

        'Dim dd1 As New clsJQuery.jqDropList("DeviceCodes_" & UID & sUnique, Pagename, True)
        'Dim dd2 As New clsJQuery.jqDropList("Commands_" & UID & sUnique, Pagename, True)

        Dim sKey As String

        'dd2.autoPostBack = True
        'dd2.AddItem("--Please Select--", "", False)

        If Not (ActInfo.DataIn Is Nothing) Then
            DeSerializeObject(ActInfo.DataIn, action)
        Else 'new event, so clean out the action object
            action = New action
        End If

        For Each sKey In action.Keys
            Select Case True
                Case InStr(sKey, "Group_" & UID) > 0
                    Group = action(sKey)
                Case InStr(sKey, "Colour_" & UID) > 0
                    Colour = action(sKey)
                Case InStr(sKey, "Program_" & UID) > 0
                    Program = action(sKey)
                Case InStr(sKey, "Value_" & UID) > 0
                    Value = action(sKey)
            End Select
        Next

        dd1.AddItem("All", "All", "All" = Group)
        For i = 1 To 7
            dd1.AddItem(i.ToString, i.ToString, (i.ToString = Group))
        Next

        dd2.AddItem("Red", "Red", "Red" = Colour)
        dd2.AddItem("Green", "Green", "Green" = Colour)
        dd2.AddItem("Blue", "Blue", "Blue" = Colour)

        For i = 0 To 7
            dd3.AddItem(i.ToString, i.ToString, (i.ToString = Program))
        Next
        dd3.AddItem("9", "9", ("9" = Program))

        Dim dd4 As New clsJQuery.jqTextBox("Value_" & UID & sUnique, "", Value, Pagename, 3, True)

        'For Each C In "ABCDEFGHIJKLMNOP"
        ' dd.AddItem(C, C, (C = Housecode))
        ' Next

        stb.Append("Select Group:")
        stb.Append(dd1.Build)

        'dd1.AddItem("All", "All", ("All" = DeviceCode))
        'For i = 1 To 16
        '    dd1.AddItem(i.ToString, i.ToString, (i.ToString = DeviceCode))
        'Next

        Select Case ActInfo.TANumber
            Case 1
                stb.Append("Select Colour:")
                stb.Append(dd2.Build)

                stb.Append("Input Value:")
                stb.Append(dd4.Build)
            Case 2
                stb.Append("Input Value:")
                stb.Append(dd4.Build)
            Case 3
                stb.Append("Select Program:")
                stb.Append(dd3.Build)
            Case Else
                WriteLog(izStd.ErrorLog, "Invalid Action Number", 0)
        End Select


        'stb.Append("Select Unit Code:")
        'stb.Append(dd1.Build)

        'For Each item In Commands.Keys
        ' dd2.AddItem(Commands(item), item, (item = Command))
        ' Next

        'stb.Append("Select Command:")
        'stb.Append(dd2.Build)

        Return stb.ToString
    End Function

    Public Function ActionProcessPostUI(ByVal PostData As Collections.Specialized.NameValueCollection, _
                                        ByVal ActInfo As IPlugInAPI.strTrigActInfo) As IPlugInAPI.strMultiReturn

        Dim Ret As New HomeSeerAPI.IPlugInAPI.strMultiReturn
        Dim UID As String
        UID = ActInfo.UID.ToString

        Ret.sResult = ""
        ' We cannot be passed info ByRef from HomeSeer, so turn right around and return this same value so that if we want, 
        '   we can exit here by returning 'Ret', all ready to go.  If in this procedure we need to change DataOut or TrigInfo,
        '   we can still do that.
        Ret.DataOut = ActInfo.DataIn
        Ret.TrigActInfo = ActInfo

        If PostData Is Nothing Then Return Ret
        If PostData.Count < 1 Then Return Ret

        If Not (ActInfo.DataIn Is Nothing) Then
            DeSerializeObject(ActInfo.DataIn, action)
        End If

        Dim parts As Collections.Specialized.NameValueCollection

        Dim sKey As String

        parts = PostData

        Try
            For Each sKey In parts.Keys
                If sKey Is Nothing Then Continue For
                If String.IsNullOrEmpty(sKey.Trim) Then Continue For
                Select Case True
                    Case InStr(sKey, "Group_" & UID) > 0, InStr(sKey, "Colour_" & UID) > 0, InStr(sKey, "Value_" & UID) > 0, InStr(sKey, "Program_" & UID) > 0
                        action.Add(CObj(parts(sKey)), sKey)
                End Select
            Next
            If Not SerializeObject(action, Ret.DataOut) Then
                Ret.sResult = IFACE_NAME & " Error, Serialization failed. Signal Action not added."
                Return Ret
            End If
        Catch ex As Exception
            Ret.sResult = "ERROR, Exception in Action UI of " & IFACE_NAME & ": " & ex.Message
            Return Ret
        End Try

        ' All OK
        Ret.sResult = ""
        Return Ret
    End Function

    Public Function ActionFormatUI(ByVal ActInfo As IPlugInAPI.strTrigActInfo) As String
        Dim stb As New StringBuilder
        Dim sKey As String
        Dim Housecode As String = ""
        Dim DeviceCode As String = ""
        Dim Command As String = ""
        Dim UID As String
        UID = ActInfo.UID.ToString

        If Not (ActInfo.DataIn Is Nothing) Then
            DeSerializeObject(ActInfo.DataIn, action)
        End If

        For Each sKey In action.Keys
            Select Case True
                Case InStr(sKey, "Housecodes_" & UID) > 0
                    Housecode = action(sKey)
                Case InStr(sKey, "DeviceCodes_" & UID) > 0
                    DeviceCode = action(sKey)
                Case InStr(sKey, "Commands_" & UID) > 0
                    Command = action(sKey)
            End Select
        Next

        stb.Append(" the system will execute the " & Commands(Command) & " command ")
        stb.Append("on Housecode " & Housecode & " ")
        If DeviceCode = "ALL" Then
            stb.Append("for all Unitcodes")
        Else
            stb.Append("for Unitcode " & DeviceCode)
        End If

        Return stb.ToString
    End Function

#End Region

#Region "Trigger Interface"

    Public ReadOnly Property TriggerConfigured(ByVal TrigInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As Boolean
        Get
            Dim Configured As Boolean = False
            Dim sKey As String
            Dim itemsConfigured As Integer = 0
            Dim itemsToConfigure As Integer = 3
            Dim UID As String
            UID = TrigInfo.UID.ToString

            If Not (TrigInfo.DataIn Is Nothing) Then
                DeSerializeObject(TrigInfo.DataIn, trigger)
                For Each sKey In trigger.Keys
                    Select Case True
                        Case InStr(sKey, "Housecodes_" & UID) > 0 AndAlso trigger(sKey) <> ""
                            itemsConfigured += 1
                        Case InStr(sKey, "DeviceCodes_" & UID) > 0 AndAlso trigger(sKey) <> ""
                            itemsConfigured += 1
                        Case InStr(sKey, "Commands_" & UID) > 0 AndAlso trigger(sKey) <> ""
                            itemsConfigured += 1
                    End Select
                Next
                If itemsConfigured = itemsToConfigure Then Configured = True
            End If
            Return Configured
        End Get
    End Property

    Public Function TriggerBuildUI(ByVal sUnique As String, ByVal TrigInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As String
        Dim UID As String
        UID = TrigInfo.UID.ToString
        Dim stb As New StringBuilder
        Dim Housecode As String = ""
        Dim DeviceCode As String = ""
        Dim Command As String = ""
        Dim dd As New clsJQuery.jqDropList("Housecodes_" & UID & sUnique, Pagename, True)
        Dim dd1 As New clsJQuery.jqDropList("DeviceCodes_" & UID & sUnique, Pagename, True)
        Dim dd2 As New clsJQuery.jqDropList("Commands_" & UID & sUnique, Pagename, True)
        Dim sKey As String

        dd.autoPostBack = True
        dd.AddItem("--Please Select--", "", False)
        dd1.autoPostBack = True
        dd1.AddItem("--Please Select--", "", False)
        dd2.autoPostBack = True
        dd2.AddItem("--Please Select--", "", False)

        If Not (TrigInfo.DataIn Is Nothing) Then
            DeSerializeObject(TrigInfo.DataIn, trigger)
        Else 'new event, so clean out the trigger object
            trigger = New trigger
        End If

        For Each sKey In trigger.Keys
            Select Case True
                Case InStr(sKey, "Housecodes_" & UID) > 0
                    Housecode = trigger(sKey)
                Case InStr(sKey, "DeviceCodes_" & UID) > 0
                    DeviceCode = trigger(sKey)
                Case InStr(sKey, "Commands_" & UID) > 0
                    Command = trigger(sKey)
            End Select
        Next

        For Each C In "ABCDEFGHIJKLMNOP"
            dd.AddItem(C, C, (C = Housecode))
        Next

        stb.Append("Select House Code:")
        stb.Append(dd.Build)

        dd1.AddItem("All", "All", ("All" = DeviceCode))
        For i = 1 To 16
            dd1.AddItem(i.ToString, i.ToString, (i.ToString = DeviceCode))
        Next

        stb.Append("Select Unit Code:")
        stb.Append(dd1.Build)

        For Each item In Commands.Keys
            dd2.AddItem(Commands(item), item, (item = Command))
        Next

        stb.Append("Select Command:")
        stb.Append(dd2.Build)


        Return stb.ToString
    End Function

    Public Function TriggerProcessPostUI(ByVal PostData As System.Collections.Specialized.NameValueCollection, _
                                                     ByVal TrigInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As HomeSeerAPI.IPlugInAPI.strMultiReturn
        Dim Ret As New HomeSeerAPI.IPlugInAPI.strMultiReturn
        Dim UID As String
        UID = TrigInfo.UID.ToString

        Ret.sResult = ""
        ' We cannot be passed info ByRef from HomeSeer, so turn right around and return this same value so that if we want, 
        '   we can exit here by returning 'Ret', all ready to go.  If in this procedure we need to change DataOut or TrigInfo,
        '   we can still do that.
        Ret.DataOut = TrigInfo.DataIn
        Ret.TrigActInfo = TrigInfo

        If PostData Is Nothing Then Return Ret
        If PostData.Count < 1 Then Return Ret

        If Not (TrigInfo.DataIn Is Nothing) Then
            DeSerializeObject(TrigInfo.DataIn, trigger)
        End If

        Dim parts As Collections.Specialized.NameValueCollection

        Dim sKey As String

        parts = PostData
        Try
            For Each sKey In parts.Keys
                If sKey Is Nothing Then Continue For
                If String.IsNullOrEmpty(sKey.Trim) Then Continue For
                Select Case True
                    Case InStr(sKey, "Housecodes_" & UID) > 0, InStr(sKey, "DeviceCodes_" & UID) > 0, InStr(sKey, "Commands_" & UID) > 0
                        trigger.Add(CObj(parts(sKey)), sKey)
                End Select
            Next
            If Not SerializeObject(trigger, Ret.DataOut) Then
                Ret.sResult = IFACE_NAME & " Error, Serialization failed. Signal Trigger not added."
                Return Ret
            End If
        Catch ex As Exception
            Ret.sResult = "ERROR, Exception in Trigger UI of " & IFACE_NAME & ": " & ex.Message
            Return Ret
        End Try

        ' All OK
        Ret.sResult = ""
        Return Ret
    End Function

    Public Function TriggerFormatUI(ByVal TrigInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As String
        Dim stb As New StringBuilder
        Dim sKey As String
        Dim Housecode As String = ""
        Dim DeviceCode As String = ""
        Dim Command As String = ""
        Dim UID As String
        UID = TrigInfo.UID.ToString

        If Not (TrigInfo.DataIn Is Nothing) Then
            DeSerializeObject(TrigInfo.DataIn, trigger)
        End If

        For Each sKey In trigger.Keys
            Select Case True
                Case InStr(sKey, "Housecodes_" & UID) > 0
                    Housecode = trigger(sKey)
                Case InStr(sKey, "DeviceCodes_" & UID) > 0
                    DeviceCode = trigger(sKey)
                Case InStr(sKey, "Commands_" & UID) > 0
                    Command = trigger(sKey)
            End Select
        Next

        stb.Append(" the system detected the " & Commands(Command) & " command ")
        stb.Append("on Housecode " & Housecode & " ")
        If DeviceCode = "ALL" Then
            stb.Append("from a Unitcode")
        Else
            stb.Append("from Unitcode " & DeviceCode)
        End If

        Return stb.ToString
    End Function

#End Region

#End Region

#Region "HomeSeer-Required Functions"

    Function name() As String
        name = IFACE_NAME
    End Function

    Public Function AccessLevel() As Integer
        AccessLevel = 2 ' 1=Free, 2=Licensed
    End Function

#End Region

#Region "Init"
    Public Function InitIO(ByVal port As String) As String
        ' Add date check here to exit PlugIn if this is beyond certain date
        ' Use OA formate to avoid issues with different culture settings
        ' Use separate code to calculate this date if it changes:
        'Dim ExpiryDate As New System.DateTime(2016, 12, 31, 0, 0, 0)
        'Dim MyDate As Double
        'MyDate = ExpiryDate.ToOADate()
        'Const ValidUntilDate As Double = 42735 ' Equate to 31/12/2016  
        'Dim ValidUntilValue As Date = DateTime.FromOADate(ValidUntilDate)

        'If Date.Now > ValidUntilValue Then
        '    hs.WriteLog(IFACE_NAME & " Error", "Trial has expired. Please buy the full product")
        '    Console.WriteLine(IFACE_NAME & " Error. Trial has expired. Please buy the full product")
        '    Return "Trial has expired. Please buy the full product"
        '    Exit Function
        'Else
        '    hs.WriteLog(IFACE_NAME & " Warning", "Beta version. Will expire at some point...")
        '    Console.WriteLine(IFACE_NAME & " Warning. Beta version. Will expire at some point...")
        'End If

        Dim ReturnVal As String = ""

        'Dim o As Object = Nothing
        RegisterWebPage(sConfigPage, "Config", , True)

        ' Register Help Page
        RegisterWebPage(sHelpPage, "Help", , False)

        'RegisterWebPage(sStatusPage)

        ' Read INI settings and initialise standard indigozest functions
        ReturnVal = IniPlugIn()
        If ReturnVal <> "" Then
            WriteLog(ErrorLog, ReturnVal, 0)
            Return ReturnVal
        End If

        ReturnVal = izInit(port)
        If ReturnVal <> "" Then
            WriteLog(ErrorLog, ReturnVal, 0)
            Return ReturnVal
        End If

        If KNXBus.IsConnected Then KNXStateChangeEvent(Knx.Bus.Common.BusConnectionStatus.Connected)

        Return ""
    End Function

    Public Sub ShutdownIO()
        Try
            Try
                hs.SaveEventsDevices()
                izShutdown()
            Catch ex As Exception
                Log("could not save devices")
            End Try
            bShutDown = True
        Catch ex As Exception
            Log("Error ending " & IFACE_NAME & " Plug-In")
        End Try

    End Sub
#End Region

#Region "Web Page Processing"

    Private Function SelectPage(ByVal pageName As String) As Object
        SelectPage = Nothing
        Select Case pageName
            Case ConfigPage.PageName
                SelectPage = ConfigPage
            Case StatusPage.PageName
                SelectPage = StatusPage
            Case Else
                SelectPage = ConfigPage
        End Select
    End Function

    Public Function postBackProc(page As String, data As String, user As String, userRights As Integer) As String
        WebPage = SelectPage(page)
        Return WebPage.postBackProc(page, data, user, userRights)
    End Function

    Public Function GetPagePlugin(ByVal pageName As String, ByVal user As String, ByVal userRights As Integer, ByVal queryString As String) As String
        ' build and return the actual page
        WebPage = SelectPage(pageName)
        Return WebPage.GetPagePlugin(pageName, user, userRights, queryString)
    End Function

#End Region

End Class
