﻿Imports HomeSeerAPI
Imports Knx
Imports Knx.Bus.Common.Configuration
Imports Knx.Falcon.Sdk
Imports Knx.Bus.Common.GroupValues
Imports Knx.Bus.Common

' Copyright (C) 2016 indigozest Ltd., www.indigozest.co.uk
' Light and Motion control module
' All Rights Reserved
'
' Revision History
' v3.0.1.13 - Adding HVAC Mode device
' v3.0.1.12 - Updating temperature devices to use correct device type and implementing HS ScaleText functionality
' v3.0.1.11 - Removing beta references
' v3.0.1.10 - Initial launch of production version
' v0.0.1.9  - Allow for large numbers and negative numbers in MantissaDecode funtion
'             More work on Thermostat support
' v0.0.1.8  - More work on thermostats and minor tidy ups
' v0.0.1.7  - Adding Scene device with DPT 18.001 support
' v0.0.1.6  - WIP for Thermostat support. Fixing issue with initial polling
' v0.0.1.5  - Fixing bug for GroupAddres validation on izKNX tab
' v0.0.1.4  - Moved GroupValueReadReceivedEvent to use new HSUpdateDevice menthod
'             Support for updating devices on inbound DPT 3.007
' v0.0.1.3  - Group Address validation against correct GA structure (2 Level/3 Level/Free)
' v0.0.1.2  - Timer based polling. Adding Binary Scene device. 
' v0.0.1.1  - Complete re-write of polling mechanism
' v0.0.1.0  - Rewriting of how updates are handled. Now taking the lead from DPT 
' v0.0.0.7  - Polling devices on startup and change to standar polling method
' v0.0.0.6  - Minor changes, including licensing variations
' v0.0.0.5  - Fixing small bug
' v0.0.0.4  - Much functionality added
' v0.0.0.3  - Adding Temperature/MotionSensor/Bind-Curtain devices
' v0.0.0.2  - Adding graphics
' v0.0.0.1  - Initial code setup and first public beta version
'
'
'
'
' TO ADD A NEW DEVICE THE FOLLOWING IS REQUIRED:
' Add entries in "Devices Constants" and "Addresses" regions
' Add the Device under the "Device Creation" Region
' Add call in izInit to update device on changes
' Check enumDataPointTypes in KNXClasses to ensure DPT exists
' Create enum in KNXClasses for the buttons for this device
' Setup DeviceInitiation code
' Write encode/decode functions if required
' Add DPT entry to UpdateHSDevice if new DPT was needed
' Update EncodeAndSend in izKNX
' Update ConfigDevice in plugin
' Update SetIOMulti in plugin

Module izKNX
    ' Pricing Structure:
    ' Basic:     $29.95
    ' Premium:   $49.95
    ' Unlimited: $99.95 
#If KNXVersion = "U" Then
    Private LicenseType As String = LicenseUnlimited  ' Basic, Premium or Unlimited
#ElseIf KNXVersion = "P" Then
    Private LicenseType As String = LicensePremium ' Basic, Premium or Unlimited
#Else
    Private LicenseType As String = LicenseBasic ' Basic, Premium or Unlimited
#End If

    'Private LicenseType As String = LicenseUnlimited ' Basic, Premium or Unlimited
    Const LicenseBasic = "Basic"
    Const LicensePremium = "Premium"
    Const LicenseUnlimited = "Unlimited"
    Const LicenseBasicCount = 20
    Const LicensePremiumCount = 250

#Region "Variables"
    Friend KNXBus As New Bus(New KnxIpTunnelingConnectorParameters())

    Friend PEDName As String = IFACE_NAME & "PED"

    Friend GroupAddressTable As New List(Of KNXGroupAddresPair)
    Friend DataPointTypeTable As New List(Of HomeSeerAPI.Pair)
    Friend ActionPairTable As New List(Of HomeSeerAPI.Pair)
    Friend _CurrentKNXRoot As Integer = 0 ' Current DIM ROOT device ref used
    Friend _GroupAddressStructure As Byte ' Determines the structure used for GroupAddresses
    Friend GATypes As New List(Of HomeSeerAPI.Pair)

    Friend Const _DimStepValue As Integer = 1 ' Number of dimming steps everytime we step dim up/down. Can be 1 to 7

    Friend _RebuildOnSave As Boolean = True ' True if the GroupAddress table is rebuilt on each device save
    Friend _ConnectionKeepAlive As Boolean = True ' Will reconnect via timer if connection is broken

    ' Timer and Call Back
    Friend WithEvents PollingTimer As Timers.Timer
    Friend _PollingFrequency As Integer = 60 * 5 ' Timer in seconds for a full poll
    Friend _TimerBasedPoll As Boolean = False

    Friend _UseEventCallBack As Boolean = False

    ' General Timer for Garbage Collection
    Friend WithEvents GeneralTimer As Timers.Timer
    Private GeneralTimerInterval As Integer = 120
    'Private UpdateDevicesMinimumVersion = "3.0.4.0" ' Used to check if devices should be updated whenever the LastVersion property is older than this variable

    Friend _IncludeLocation1 As Boolean = True ' Denotes where Location 1 is included in the device lists
    Friend _IncludeLocation2 As Boolean = True ' Denotes where Location 2 is included in the device lists

    Friend izTemperatureScale As String = "" ' Used when updating temperature/setpoint devices to get the correct scale
#End Region

#Region "Device Constants"
    Friend SuffixKNXRoot As String = "-ROOT"
    Friend TypeKNXRoot As String = " Root"

    Friend SuffixBinary As String = "-BINARY"
    Friend TypeBinary As String = " Binary"

    Friend SuffixDimmer As String = "-DIMMER"
    Friend TypeDimmer As String = " Dimmer"

    Friend SuffixTemperatureSensor As String = "-TEMPERATURE"
    Friend TypeTemperature As String = " Temperature"

    Friend SuffixMotionSensorRoot As String = "-MOTIONROOT"
    Friend TypeMotionSensorRoot As String = " Motion Root"
    Friend SuffixMotionOccupancy As String = "-OCCUPANCY"
    Friend TypeMotionOccupancy As String = " Occupancy"
    Friend SuffixLuxLevel As String = "-LUXLEVEL"
    Friend TypeLuxLevel As String = " Lux Level"

    Friend SuffixBlindCurtain As String = "-BLINDCURTAIN"
    Friend TypeBlindCurtain As String = " BlindCurtain"

    Friend SuffixBinaryScene As String = "-BINARYSCENE"
    Friend TypeBinaryScene As String = " Binary Scene"

    Friend SuffixScene As String = "-SCENE"
    Friend TypeScene As String = " Scene"

    Friend SuffixTStatRoot As String = "-TSTATROOT"
    Friend TypeTStatRoot As String = " TStat Root"
    Friend SuffixTStatTemperature As String = "-TSTATTEMPERATURE"
    Friend TypeTStatTemperature As String = " TStat Temperature"
    Friend SuffixTStatSetPoint As String = "-SETPOINT"
    Friend TypeTStatSetPoint As String = " SetPoint"
    Friend SuffixTStatHVACMode As String = "-HVACMODE"
    Friend TypeTStatHVACMode As String = " HVAC Mode"
    Friend SuffixTStatHVACStatus As String = "-STATUS"
    Friend TypeTStatHVACStatus As String = " Status"
    Friend SuffixTStatSensorAlarm As String = "-SENSORALARM"
    Friend TypeTStatSensorAlarm As String = " Sensor Alarm"
    Friend SuffixTStatHeatingValve As String = "-HEATINGVALVE"
    Friend TypeTStatHeatingValve As String = " Heating Valve"
    Friend SuffixTStatCoolingValve As String = "-COOLINGVALVE"
    Friend TypeTStatCoolingValve As String = " Cooling Valve"
    ' We also need: HVAC Mode (auto, heat, cool), MODE (Comfort, eco, standby, heat protection), Status (on/off)

#End Region

#Region "Addresses"
    Friend Function AddressKNXRootDevice() As String
        Return IFACE_NAME & SuffixKNXRoot
    End Function
    Friend Function AddressBinaryDevice() As String
        Return IFACE_NAME & SuffixBinary
    End Function
    Friend Function AddressDimmerDevice() As String
        Return IFACE_NAME & SuffixDimmer
    End Function
    Friend Function AddressTemperatureDevice() As String
        Return IFACE_NAME & SuffixTemperatureSensor
    End Function
    Friend Function AddressMotionSensorRootDevice() As String
        Return IFACE_NAME & SuffixMotionSensorRoot
    End Function
    Friend Function AddressMotionOccupancyDevice() As String
        Return IFACE_NAME & SuffixMotionOccupancy
    End Function
    Friend Function AddressLuxLevelDevice() As String
        Return IFACE_NAME & SuffixLuxLevel
    End Function
    Friend Function AddressBlindCurtainDevice() As String
        Return IFACE_NAME & SuffixBlindCurtain
    End Function
    Friend Function AddressBinarySceneDevice() As String
        Return IFACE_NAME & SuffixBinaryScene
    End Function
    Friend Function AddressSceneDevice() As String
        Return IFACE_NAME & SuffixScene
    End Function
    Friend Function AddressTStatRootDevice() As String
        Return IFACE_NAME & SuffixTStatRoot
    End Function
    Friend Function AddressTStatTemperatureDevice() As String
        Return IFACE_NAME & SuffixTStatTemperature
    End Function
    Friend Function AddressTStatSetPointDevice() As String
        Return IFACE_NAME & SuffixTStatSetPoint
    End Function
    Friend Function AddressTStatHVACMode() As String
        Return IFACE_NAME & SuffixTStatHVACMode
    End Function
    Friend Function AddressTStatHVACStatus() As String
        Return IFACE_NAME & SuffixTStatHVACStatus
    End Function
    Friend Function AddressTStatSensorAlarm() As String
        Return IFACE_NAME & SuffixTStatSensorAlarm
    End Function
    Friend Function AddressTStatHeatingValve() As String
        Return IFACE_NAME & SuffixTStatHeatingValve
    End Function
    Friend Function AddressTStatCoolingValve() As String
        Return IFACE_NAME & SuffixTStatCoolingValve
    End Function
#End Region

#Region "Properties (INI file)"
    Private Function IniLineName(ByRef IniStr As String) As String
        Return Left(IniStr, InStr(IniStr, "=") - 1)
    End Function
    Private Function IniLineValsStr(ByRef IniStr As String) As String()
        Dim Vals As String = Right(IniStr, IniStr.Length - InStr(IniStr, "="))
        Return Vals.Split(",")
    End Function
    Private Function IniLineValsInt(ByRef IniStr As String) As String()
        Dim Vals As String = Right(IniStr, IniStr.Length - InStr(IniStr, "="))
        Dim ValArr() As String = Vals.Split(",")
        Dim ValArrInt(ValArr.Length - 1) As String
        Dim i As Integer = 0
        For i = 0 To ValArr.Length - 1
            ValArrInt(i) = ValArr(i)
        Next
        Return ValArrInt
    End Function
    Friend Property PollingFrequency() As Integer
        Get
            Dim ReadStr As String = hs.GetINISetting(IniSection, "Polling Frequency", "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(IniSection, "Polling Frequency", "60", IniFileName)
                Return 0
            Else
                Return Val(ReadStr)
            End If
        End Get
        Set(value As Integer)
            hs.SaveINISetting(IniSection, "Polling Frequency", value.ToString, IniFileName)
        End Set
    End Property
    Friend Property TimerBasedPoll() As Boolean
        Get
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            Dim ReadStr As String = hs.GetINISetting(IniSection, IniEntryName, "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(IniSection, IniEntryName, "FALSE", IniFileName)
                Return False
            Else
                Return CBool(ReadStr)
            End If
        End Get
        Set(value As Boolean)
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            hs.SaveINISetting(IniSection, IniEntryName, value, IniFileName)
        End Set
    End Property
    Friend ReadOnly Property CurrentVersion() As String
        Get
            Try
                Dim myFileVersionInfo As FileVersionInfo = FileVersionInfo.GetVersionInfo("HSPI_izKNX.exe")
                Return myFileVersionInfo.FileVersion
            Catch ex As Exception
                CurrentVersion = LastVersion
            End Try
        End Get
    End Property
    Friend Property LastVersion() As String
        Get
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            Dim ReadStr As String = hs.GetINISetting(IniSection, IniEntryName, "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(IniSection, IniEntryName, "3.0.0.1", IniFileName)
                Return 1
            Else
                Return ReadStr
            End If
        End Get
        Set(value As String)
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            hs.SaveINISetting(IniSection, IniEntryName, value.ToString, IniFileName)
        End Set
    End Property
    Friend Property IncludeLocation1() As Boolean
        Get
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            Dim ReadStr As String = hs.GetINISetting(IniSection, IniEntryName, "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(IniSection, IniEntryName, "FALSE", IniFileName)
                Return False
            Else
                Return CBool(ReadStr)
            End If
        End Get
        Set(value As Boolean)
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            hs.SaveINISetting(IniSection, IniEntryName, value, IniFileName)
        End Set
    End Property
    Friend Property IncludeLocation2() As Boolean
        Get
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            Dim ReadStr As String = hs.GetINISetting(IniSection, IniEntryName, "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(IniSection, IniEntryName, "FALSE", IniFileName)
                Return False
            Else
                Return CBool(ReadStr)
            End If
        End Get
        Set(value As Boolean)
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            hs.SaveINISetting(IniSection, IniEntryName, value, IniFileName)
        End Set
    End Property
    Friend Property IPAddress() As String
        Get
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            Dim ReadStr As String = hs.GetINISetting(IniSection, IniEntryName, "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(IniSection, IniEntryName, "192.168.1.94", IniFileName)
                Return False
            Else
                Return CStr(ReadStr)
            End If
        End Get
        Set(value As String)
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            hs.SaveINISetting(IniSection, IniEntryName, value, IniFileName)
        End Set
    End Property
    Friend Property KNXPort() As String
        Get
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            Dim ReadStr As String = hs.GetINISetting(IniSection, IniEntryName, "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(IniSection, IniEntryName, "3671", IniFileName)
                Return False
            Else
                Return CStr(ReadStr)
            End If
        End Get
        Set(value As String)
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            hs.SaveINISetting(IniSection, IniEntryName, value, IniFileName)
        End Set
    End Property
    Friend Property UseNAT() As Boolean
        Get
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            Dim ReadStr As String = hs.GetINISetting(IniSection, IniEntryName, "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(IniSection, IniEntryName, "FALSE", IniFileName)
                Return False
            Else
                Return CBool(ReadStr)
            End If
        End Get
        Set(value As Boolean)
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            hs.SaveINISetting(IniSection, IniEntryName, value, IniFileName)
        End Set
    End Property
    Friend Property RebuildOnSave() As Boolean
        Get
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            Dim ReadStr As String = hs.GetINISetting(IniSection, IniEntryName, "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(IniSection, IniEntryName, "TRUE", IniFileName)
                Return True
            Else
                Return CBool(ReadStr)
            End If
        End Get
        Set(value As Boolean)
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            hs.SaveINISetting(IniSection, IniEntryName, value, IniFileName)
        End Set
    End Property
    Friend Property ConnectionKeepAlive() As Boolean
        Get
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            Dim ReadStr As String = hs.GetINISetting(IniSection, IniEntryName, "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(IniSection, IniEntryName, "TRUE", IniFileName)
                Return True
            Else
                Return CBool(ReadStr)
            End If
        End Get
        Set(value As Boolean)
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            hs.SaveINISetting(IniSection, IniEntryName, value, IniFileName)
        End Set
    End Property
    Friend Property GroupAddressStructure() As Byte
        Get
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            Dim ReadStr As String = hs.GetINISetting(IniSection, IniEntryName, "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(IniSection, IniEntryName, "3", IniFileName)
                Return False
            Else
                Return CByte(ReadStr)
            End If
        End Get
        Set(value As Byte)
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            hs.SaveINISetting(IniSection, IniEntryName, value, IniFileName)
        End Set
    End Property

#End Region

#Region "Timer Event"
    Private Sub PollingTimer_Elapsed(ByVal sender As Object, ByVal e As System.Timers.ElapsedEventArgs) Handles PollingTimer.Elapsed
        Dim Result As String = ""
        Try
            'Do Polling etc.
            For Each Entry In GroupAddressTable
                If Entry.PollMe Then KNXPollDevice(Entry.dvRef, True)
            Next
            WriteLog(DebugLog, "Running Polling Timer", 3)
        Catch ex As Exception
            WriteLog(ErrorLog, "Error in Timer function. Error message: " & ex.Message, 0)
        End Try
    End Sub
    Friend Sub GeneralTimer_Elapsed(ByVal sender As Object, ByVal e As System.Timers.ElapsedEventArgs) Handles GeneralTimer.Elapsed
        ' Used for general timer based tasks. Runs once per minute
        WriteLog(DebugLog, "Running General Timer", 5)
        GC.Collect()  'Collect garbage from other threads etc.
        WriteLog(DebugLog, "Garbage Collection Complete", 5)
        CheckKNXBusConnection()

    End Sub
#End Region

#Region "Init and Shutdown"
    Friend Function izInit(ByRef port As String) As String
        Dim ReturnVal As String = ""

        Try
            WriteLog(DebugLog, "In izInit...", 5)
            WriteLog(InfoLog, "Starting " & IFACE_NAME & " " & LicenseType & " ...", 0)

            ' First initialise settings from izStandards
            izStd.IniPlugIn()

            KNXSetupConnection()
            _GroupAddressStructure = GroupAddressStructure
            Dim SingleGAType As New HomeSeerAPI.Pair
            SingleGAType.Name = "Free"
            SingleGAType.Value = 1
            GATypes.Add(SingleGAType)
            SingleGAType.Name = "2-level"
            SingleGAType.Value = 2
            GATypes.Add(SingleGAType)
            SingleGAType.Name = "3-level"
            SingleGAType.Value = 3
            GATypes.Add(SingleGAType)

            GroupAddressTable = BuildGATable()
            DataPointTypeTable = BuildDPTList()
            ActionPairTable = BuildActionPairList()
            _RebuildOnSave = RebuildOnSave
            _ConnectionKeepAlive = ConnectionKeepAlive

            ' Temperature Scale
            If hs.GetINISetting("Settings", "gGlobalTempScaleF", "True").ToUpper = "TRUE" Then
                izTemperatureScale = Chr(176) & "F"
            Else
                izTemperatureScale = Chr(176) & "C"
            End If

            ' Now check if MOTION devices exists, by looking up the first one, or alternatively create
            _CurrentKNXRoot = hs.DeviceExistsAddress(AddressKNXRootDevice, False)
            If _CurrentKNXRoot = -1 Then
                WriteLog(DebugLog, "Creating devices...", 3)
                ReturnVal = CreateKNXRootDevice()

                ReturnVal = CreateBinaryDevice()
                ReturnVal = CreateDimmerDevice()
                ReturnVal = CreateTemperatureDevice()
                ReturnVal = CreateMotionSensorGroup()
                ReturnVal = CreateBlindCurtainDevice()

                If ReturnVal <> "" Then Return ReturnVal
            Else
                WriteLog(DebugLog, "Device: " & AddressKNXRootDevice() & " already exists. No need to create devices", 3)
            End If

            ' Now check if any devices needs updating
            Dim UpdateDevices As Boolean = False
            If 1 = 1 Then
                UpdateDevices = True ' LastVersion < CurrentVersion Then
                WriteLog(DebugLog, "Updating Devices to latest version: " & CurrentVersion & " from version: " & LastVersion, 3)
                WriteLog(DebugLog, "Updating Root Device to latest version", 3)
                CreateKNXRootDevice(_CurrentKNXRoot)
            End If

            ' Now enumerate through all devices. Update them if required and Poll them if possible
            Try
                Dim dv As Scheduler.Classes.DeviceClass
                Dim EN As Scheduler.Classes.clsDeviceEnumeration
                EN = hs.GetDeviceEnumerator
                If EN Is Nothing Then
                    Return "Error getting Enumerator in izInit"
                End If
                Do
                    dv = EN.GetNext
                    If dv Is Nothing Then Continue Do

                    If dv.Interface(Nothing) = IFACE_NAME Then
                        If UpdateDevices Then
                            Dim AdrLookup As String = dv.Address(Nothing)
                            AdrLookup = Right(AdrLookup, Len(AdrLookup) - InStr(AdrLookup, "-") + 1)
                            Select Case AdrLookup
                                Case SuffixBinary
                                    WriteLog(DebugLog, "Updating dvRef " & dv.Ref(Nothing) & " Binary Light device to latest version", 3)
                                    CreateBinaryDevice(dv.Ref(Nothing))
                                Case SuffixDimmer
                                    WriteLog(DebugLog, "Updating dvRef " & dv.Ref(Nothing) & " Light Dimmer device to latest version", 3)
                                    CreateDimmerDevice(dv.Ref(Nothing))
                                Case SuffixTemperatureSensor
                                    WriteLog(DebugLog, "Updating dvRef " & dv.Ref(Nothing) & " Temperature device to latest version", 3)
                                    CreateTemperatureDevice(dv.Ref(Nothing))
                                Case SuffixMotionSensorRoot
                                    WriteLog(DebugLog, "Updating dvRef " & dv.Ref(Nothing) & " Motion Sensor Root device to latest version", 3)
                                    CreateMotionSensorRootDevice(dv.Ref(Nothing))
                                Case SuffixMotionOccupancy
                                    WriteLog(DebugLog, "Updating dvRef " & dv.Ref(Nothing) & " Motion Sensor Occupancy device to latest version", 3)
                                    CreateMotionOccupancyDevice(-1, dv.Ref(Nothing))
                                Case SuffixLuxLevel
                                    WriteLog(DebugLog, "Updating dvRef " & dv.Ref(Nothing) & " Lux Level device to latest version", 3)
                                    CreateLuxLevelDevice(-1, dv.Ref(Nothing))
                                Case SuffixBlindCurtain
                                    WriteLog(DebugLog, "Updating dvRef " & dv.Ref(Nothing) & " Blind/Curtain device to latest version", 3)
                                    CreateBlindCurtainDevice(dv.Ref(Nothing))
                                Case SuffixScene
                                    WriteLog(DebugLog, "Updating dvRef " & dv.Ref(Nothing) & " Scene device to latest version", 3)
                                    CreateSceneDevice(dv.Ref(Nothing))
                                Case SuffixBinaryScene
                                    WriteLog(DebugLog, "Updating dvRef " & dv.Ref(Nothing) & " Binary Scene device to latest version", 3)
                                    CreateBinarySceneDevice(dv.Ref(Nothing))
                                Case SuffixTStatRoot
                                    WriteLog(DebugLog, "Updating dvRef " & dv.Ref(Nothing) & " Thermostat Root device to latest version", 3)
                                    CreateTStatRootDevice(dv.Ref(Nothing))
                                Case SuffixTStatSetPoint
                                    WriteLog(DebugLog, "Updating dvRef " & dv.Ref(Nothing) & " Thermostat Setpoint device to latest version", 3)
                                    CreateTStatSetPointDevice(-1, dv.Ref(Nothing))
                                Case SuffixTStatTemperature
                                    WriteLog(DebugLog, "Updating dvRef " & dv.Ref(Nothing) & " Thermostat Temperature device to latest version", 3)
                                    CreateTStatTemperatureDevice(-1, dv.Ref(Nothing))
                                Case SuffixTStatHeatingValve
                                    WriteLog(DebugLog, "Updating dvRef " & dv.Ref(Nothing) & " Thermostat Heating Valve device to latest version", 3)
                                    CreateTStatHeatingValveDevice(-1, dv.Ref(Nothing))
                                Case SuffixTStatHVACMode
                                    WriteLog(DebugLog, "Updating dvRef " & dv.Ref(Nothing) & " Thermostat HVAC Mode device to latest version", 3)
                                    CreateTSTatHVACModeDevice(-1, dv.Ref(Nothing))
                            End Select
                        End If

                        ' Poll device
                        KNXPollDevice(dv.Ref(Nothing), False)
                    End If
                Loop Until EN.Finished
            Catch ex As Exception
                hs.WriteLog("Error", "Exception in device enumeration: " & ex.Message)
                Return "Error updating devices to latest version"
            End Try

            LastVersion = CurrentVersion


            ' Now deal with polling
            _TimerBasedPoll = TimerBasedPoll
            _PollingFrequency = PollingFrequency
            If _TimerBasedPoll Then
                ' Setup timer for regular status updates
                WriteLog(DebugLog, "Polling frequency: " & _PollingFrequency, 5)
                If _PollingFrequency > 0 Then
                    PollingTimer = New System.Timers.Timer(1000 * _PollingFrequency)
                    PollingTimer.Enabled = True
                    PollingTimer.Start()
                End If
            End If

            ' Setup General timer
            GeneralTimer = New System.Timers.Timer(1000 * GeneralTimerInterval)
            GeneralTimer.Enabled = True
            GeneralTimer.Start()

            WriteLog(InfoLog, IFACE_NAME & " " & LicenseType & " now started.", 0)
            WriteLog(DebugLog, "Initialised, up And running...", 3)

        Catch ex As Exception
            WriteLog(DebugLog, "Exception from izInit: " & ex.Message, 0)
            Return "Exception from izInit: " & ex.Message
        End Try

        Return ""
    End Function

    Friend Function izShutdown() As Boolean
        'Thread.Sleep(1000)
        WriteLog(DebugLog, "izShutdown. Shutting down Plug-In ...", 5)
        LastVersion = CurrentVersion
        KNXCloseConnection()
        Return True
    End Function
#End Region

#Region "Device Creation" ' Set up as region only to keep Ini proc neat
    Private Function PollExists(ByVal ref As Integer) As Boolean
        Dim ExistingReadVS As VSPair = hs.DeviceVSP_Get(ref, enumRootActions.Poll, ePairStatusControl.Control)
        If ExistingReadVS IsNot Nothing Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Function CreateKNXRootDevice(Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            dv = hs.GetDeviceByRef(ref)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            dv = hs.GetDeviceByRef(ref)
            dv.Address(hs) = AddressKNXRootDevice()
            dv.Name(hs) = IFACE_NAME & TypeKNXRoot
            dv.Location(hs) = IFACE_NAME
            dv.Location2(hs) = IFACE_NAME
            hs.SetDeviceValueByRef(ref, enumRootActions.Unknown, True)
            dv.Last_Change(hs) = Now
        End If

        dv.Device_Type_String(hs) = IFACE_NAME & TypeKNXRoot

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceType_GenericRoot
        DT.Device_SubType_Description = "KNX Root Device"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        hs.DeviceVSP_ClearAll(ref, True)
        hs.DeviceVGP_ClearAll(ref, True)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, enumRootActions.Unknown, enumBinaryActions.Unknown.ToString, 0, 0)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, BusConnectionStatus.Connected, BusConnectionStatus.Connected.ToString, 0, 0)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, BusConnectionStatus.Closed, BusConnectionStatus.Closed.ToString, 0, 0)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, BusConnectionStatus.Broken, BusConnectionStatus.Broken.ToString, 0, 0)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumRootActions.Connect, enumRootActions.Connect.ToString, 1, 1)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumRootActions.Disconnect, enumRootActions.Disconnect.ToString, 1, 2)
        If RtnMsg <> "" Then Return RtnMsg

        dv.Image(hs) = "\images\izKNX\knx_logo.png"

        Dim GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = BusConnectionStatus.Broken
        GPair.Graphic = "/images/HomeSeer/status/electricity.gif"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = BusConnectionStatus.Closed
        GPair.Graphic = "/images/HomeSeer/status/alarm.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = BusConnectionStatus.Connected
        GPair.Graphic = "/images/HomeSeer/status/ok.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        dv.Relationship(hs) = Enums.eRelationship.Parent_Root
        _CurrentKNXRoot = ref

        dv = Nothing

        Return ""
    End Function
    Friend Function CreateBinaryDevice(Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            dv = hs.GetDeviceByRef(ref)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            dv = hs.GetDeviceByRef(ref)
            dv.Address(hs) = AddressBinaryDevice()
            dv.Name(hs) = TypeBinary
            dv.Location(hs) = IFACE_NAME
            dv.Location2(hs) = IFACE_NAME
            hs.SetDeviceValueByRef(ref, enumBinaryActions.Unknown, True)
            dv.Last_Change(hs) = Now
        End If

        dv.Device_Type_String(hs) = IFACE_NAME & TypeBinary

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceType_GenericRoot
        DT.Device_SubType_Description = "KNX Binary Device"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        Dim ExistingPollButton As Boolean = False
        If ExistingDeviceRef <> -1 Then ExistingPollButton = PollExists(ExistingDeviceRef)

        hs.DeviceVSP_ClearAll(ref, True)
        hs.DeviceVGP_ClearAll(ref, True)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, enumBinaryActions.Unknown, enumBinaryActions.Unknown.ToString, 0, 0)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, enumBinaryActions.On, enumBinaryActions.On.ToString, 1, 1,,, ePairControlUse._On)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, enumBinaryActions.Off, enumBinaryActions.Off.ToString, 1, 2,,, ePairControlUse._Off)
        If RtnMsg <> "" Then Return RtnMsg

        If ExistingPollButton Then
            dv.Status_Support(hs) = True
            RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumRootActions.Poll, enumRootActions.Poll.ToString, 1, 3)
            If RtnMsg <> "" Then Return RtnMsg
        End If

        dv.Relationship(hs) = Enums.eRelationship.Parent_Root

        dv = Nothing

        Return ""
    End Function
    Friend Function CreateDimmerDevice(Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            dv = hs.GetDeviceByRef(ref)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            dv = hs.GetDeviceByRef(ref)
            dv.Address(hs) = AddressDimmerDevice()
            dv.Name(hs) = TypeDimmer
            dv.Location(hs) = IFACE_NAME
            dv.Location2(hs) = IFACE_NAME
            hs.SetDeviceValueByRef(ref, enumDimmerActions.Unknown, True)
            dv.Last_Change(hs) = Now
        End If

        dv.Device_Type_String(hs) = IFACE_NAME & TypeDimmer

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceType_GenericRoot
        DT.Device_SubType_Description = "KNX Dimmer Device"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        Dim ExistingPollButton As Boolean = False
        If ExistingDeviceRef <> -1 Then ExistingPollButton = PollExists(ExistingDeviceRef)

        hs.DeviceVSP_ClearAll(ref, True)
        hs.DeviceVGP_ClearAll(ref, True)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, enumDimmerActions.Unknown, enumDimmerActions.Unknown.ToString, 0, 0)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, enumDimmerActions.On, enumDimmerActions.On.ToString, 1, 1,,, ePairControlUse._On)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, enumDimmerActions.Off, enumDimmerActions.Off.ToString, 1, 2,,, ePairControlUse._Off)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumDimmerActions.Start_Brighten, "Brighten", 2, 1)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumDimmerActions.Stop_Dim_Action, "Stop", 2, 2)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumDimmerActions.Start_Dimming, "Dim", 2, 3)
        If RtnMsg <> "" Then Return RtnMsg

        Dim MyVSP As New VSPair(ePairStatusControl.Both)
        MyVSP.PairType = VSVGPairType.Range
        MyVSP.Render_Location.Row = 1
        MyVSP.Render_Location.Column = 3
        MyVSP.Render_Location.ColumnSpan = 5
        MyVSP.IncludeValues = True
        MyVSP.RangeStart = 1
        MyVSP.RangeEnd = 99
        MyVSP.RangeStatusSuffix = "%"
        MyVSP.Render = Enums.CAPIControlType.ValuesRangeSlider
        MyVSP.ControlUse = ePairControlUse._Dim
        If Not hs.DeviceVSP_AddPair(ref, MyVSP) Then
            WriteLog(ErrorLog, "VSPair could Not be added for device, ref: " & ref.ToString, 0)
            Return "VSPair could Not be added for device, ref: " & ref.ToString
        End If

        Dim GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = 0
        GPair.Graphic = "/images/HomeSeer/status/off.gif"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.Range
        GPair.RangeStart = 1
        GPair.RangeEnd = 9
        GPair.Graphic = "/images/HomeSeer/status/dim-00.gif"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.Range
        GPair.RangeStart = 10
        GPair.RangeEnd = 19
        GPair.Graphic = "/images/HomeSeer/status/dim-10.gif"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.Range
        GPair.RangeStart = 20
        GPair.RangeEnd = 29
        GPair.Graphic = "/images/HomeSeer/status/dim-20.gif"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.Range
        GPair.RangeStart = 30
        GPair.RangeEnd = 39
        GPair.Graphic = "/images/HomeSeer/status/dim-30.gif"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.Range
        GPair.RangeStart = 40
        GPair.RangeEnd = 49
        GPair.Graphic = "/images/HomeSeer/status/dim-40.gif"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.Range
        GPair.RangeStart = 50
        GPair.RangeEnd = 59
        GPair.Graphic = "/images/HomeSeer/status/dim-50.gif"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.Range
        GPair.RangeStart = 60
        GPair.RangeEnd = 69
        GPair.Graphic = "/images/HomeSeer/status/dim-60.gif"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.Range
        GPair.RangeStart = 70
        GPair.RangeEnd = 79
        GPair.Graphic = "/images/HomeSeer/status/dim-70.gif"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.Range
        GPair.RangeStart = 80
        GPair.RangeEnd = 89
        GPair.Graphic = "/images/HomeSeer/status/dim-80.gif"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.Range
        GPair.RangeStart = 90
        GPair.RangeEnd = 94
        GPair.Graphic = "/images/HomeSeer/status/dim-90.gif"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.Range
        GPair.RangeStart = 95
        GPair.RangeEnd = 100
        GPair.Graphic = "/images/HomeSeer/status/on.gif"
        hs.DeviceVGP_AddPair(ref, GPair)

        If ExistingPollButton Then
            dv.Status_Support(hs) = True
            RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumRootActions.Poll, enumRootActions.Poll.ToString, 2, 4)
            If RtnMsg <> "" Then Return RtnMsg
        End If

        dv.Relationship(hs) = Enums.eRelationship.Parent_Root

        dv = Nothing

        Return ""
    End Function
    Friend Function CreateTemperatureDevice(Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            dv = hs.GetDeviceByRef(ref)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            dv = hs.GetDeviceByRef(ref)
            dv.Address(hs) = AddressTemperatureDevice()
            dv.Name(hs) = TypeTemperature
            dv.Location(hs) = IFACE_NAME
            dv.Location2(hs) = IFACE_NAME
            hs.SetDeviceValueByRef(ref, enumRootActions.Unknown, True)
            dv.Last_Change(hs) = Now
        End If

        dv.Device_Type_String(hs) = IFACE_NAME & TypeTemperature

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Thermostat
        DT.Device_Type = DeviceTypeInfo_m.DeviceTypeInfo.eDeviceType_Thermostat.Temperature
        DT.Device_SubType_Description = "KNX Temperature Device"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        Dim ExistingPollButton As Boolean = False
        If ExistingDeviceRef <> -1 Then ExistingPollButton = PollExists(ExistingDeviceRef)

        hs.DeviceVSP_ClearAll(ref, True)
        hs.DeviceVGP_ClearAll(ref, True)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, enumRootActions.Unknown, enumRootActions.Unknown.ToString, 0, 0)
        If RtnMsg <> "" Then Return RtnMsg

        Dim MyVSP As New VSPair(ePairStatusControl.Status)
        MyVSP.PairType = VSVGPairType.Range
        MyVSP.Render_Location.Row = 1
        MyVSP.Render_Location.Column = 1
        MyVSP.IncludeValues = True
        MyVSP.RangeStart = -120
        MyVSP.RangeEnd = 120
        MyVSP.RangeStatusSuffix = VSPair.ScaleReplace
        MyVSP.HasScale = True
        MyVSP.RangeStatusDecimals = 2
        MyVSP.Render = Enums.CAPIControlType.ValuesRange
        hs.DeviceVSP_AddPair(ref, MyVSP)
        If Not hs.DeviceVSP_AddPair(ref, MyVSP) Then
            WriteLog(ErrorLog, "VSPair could Not be added for device, ref: " & ref.ToString, 0)
            Return "VSPair could Not be added for device, ref: " & ref.ToString
        End If

        Dim GPair = New VGPair
        GPair.PairType = VSVGPairType.Range
        GPair.RangeStart = -120
        GPair.RangeEnd = 120
        GPair.Graphic = "/images/HomeSeer/status/Thermometer-50.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        If ExistingPollButton Then
            dv.Status_Support(hs) = True
            RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumRootActions.Poll, enumRootActions.Poll.ToString, 1, 1)
            If RtnMsg <> "" Then Return RtnMsg
        End If

        dv.Relationship(hs) = Enums.eRelationship.Parent_Root

        dv = Nothing

        Return ""
    End Function
    Friend Function CreateBlindCurtainDevice(Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            dv = hs.GetDeviceByRef(ref)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            dv = hs.GetDeviceByRef(ref)
            dv.Address(hs) = AddressBlindCurtainDevice()
            dv.Name(hs) = TypeBlindCurtain
            dv.Location(hs) = IFACE_NAME
            dv.Location2(hs) = IFACE_NAME
            hs.SetDeviceValueByRef(ref, enumBlindCurtainActions.Unknown, True)
            dv.Last_Change(hs) = Now
        End If

        dv.Device_Type_String(hs) = IFACE_NAME & TypeBlindCurtain

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceType_GenericRoot
        DT.Device_SubType_Description = "KNX BlindCurtain Device"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        Dim ExistingPollButton As Boolean = False
        If ExistingDeviceRef <> -1 Then ExistingPollButton = PollExists(ExistingDeviceRef)

        hs.DeviceVSP_ClearAll(ref, True)
        hs.DeviceVGP_ClearAll(ref, True)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, enumBlindCurtainActions.Unknown, enumBlindCurtainActions.Unknown.ToString, 0, 0)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, enumBlindCurtainActions.Open, enumBlindCurtainActions.Open.ToString, 1, 1,,, ePairControlUse._On)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, enumBlindCurtainActions.Close, enumBlindCurtainActions.Close.ToString, 1, 2,,, ePairControlUse._Off)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumBlindCurtainActions.Start_Opening, "Start Opening", 2, 1)
        If RtnMsg <> "" Then Return RtnMsg
        'RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumBlindCurtainActions.Stop_OpenClose_Action, "Stop", 2, 2)
        'If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumBlindCurtainActions.Start_Closing, "Start Closing", 2, 2)
        If RtnMsg <> "" Then Return RtnMsg

        Dim GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = enumBlindCurtainActions.Close
        GPair.Graphic = "/images/HomeSeer/status/closed.png"
        hs.DeviceVGP_AddPair(ref, GPair)


        GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = enumBlindCurtainActions.Open
        GPair.Graphic = "/images/HomeSeer/status/open.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        If ExistingPollButton Then
            dv.Status_Support(hs) = True
            RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumRootActions.Poll, enumRootActions.Poll.ToString, 1, 3)
            If RtnMsg <> "" Then Return RtnMsg
        End If

        dv.Relationship(hs) = Enums.eRelationship.Parent_Root

        dv = Nothing

        Return ""
    End Function
    Friend Function CreateBinarySceneDevice(Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            dv = hs.GetDeviceByRef(ref)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            dv = hs.GetDeviceByRef(ref)
            dv.Address(hs) = AddressBinarySceneDevice()
            dv.Name(hs) = TypeBinaryScene
            dv.Location(hs) = IFACE_NAME
            dv.Location2(hs) = IFACE_NAME
            hs.SetDeviceValueByRef(ref, enumBinarySceneActions.Unknown, True)
            dv.Last_Change(hs) = Now
        End If

        dv.Device_Type_String(hs) = IFACE_NAME & TypeBinaryScene

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceType_GenericRoot
        DT.Device_SubType_Description = "KNX Binary Scene Device"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        Dim ExistingPollButton As Boolean = False
        If ExistingDeviceRef <> -1 Then ExistingPollButton = PollExists(ExistingDeviceRef)

        hs.DeviceVSP_ClearAll(ref, True)
        hs.DeviceVGP_ClearAll(ref, True)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, enumBinarySceneActions.Unknown, enumBinarySceneActions.Unknown.ToString, 0, 0)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, enumBinarySceneActions.SceneOn, "Scene On", 1, 1,,, ePairControlUse._On)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, enumBinarySceneActions.SceneOff, "Scene Off", 1, 2,,, ePairControlUse._Off)
        If RtnMsg <> "" Then Return RtnMsg

        If ExistingPollButton Then
            dv.Status_Support(hs) = True
            RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumRootActions.Poll, enumRootActions.Poll.ToString, 1, 3)
            If RtnMsg <> "" Then Return RtnMsg
        End If

        dv.Relationship(hs) = Enums.eRelationship.Parent_Root

        dv = Nothing

        Return ""
    End Function
    Friend Function CreateSceneDevice(Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            dv = hs.GetDeviceByRef(ref)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            dv = hs.GetDeviceByRef(ref)
            dv.Address(hs) = AddressSceneDevice()
            dv.Name(hs) = TypeScene
            dv.Location(hs) = IFACE_NAME
            dv.Location2(hs) = IFACE_NAME
            hs.SetDeviceValueByRef(ref, enumSceneActions.Unknown, True)
            dv.Last_Change(hs) = Now
        End If

        dv.Device_Type_String(hs) = IFACE_NAME & TypeScene

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceType_GenericRoot
        DT.Device_SubType_Description = "KNX Scene Device"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        Dim ExistingPollButton As Boolean = False
        If ExistingDeviceRef <> -1 Then ExistingPollButton = PollExists(ExistingDeviceRef)

        hs.DeviceVSP_ClearAll(ref, True)
        hs.DeviceVGP_ClearAll(ref, True)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, enumSceneActions.Unknown, enumSceneActions.Unknown.ToString, 0, 0)
        If RtnMsg <> "" Then Return RtnMsg

        Dim MyVSP As New VSPair(ePairStatusControl.Both)
        For i = 1 To 64
            MyVSP = New VSPair(ePairStatusControl.Both)
            MyVSP.PairType = VSVGPairType.SingleValue
            MyVSP.Value = i
            MyVSP.Status = "Activate " & i
            MyVSP.Render = Enums.CAPIControlType.Single_Text_from_List
            MyVSP.StringListAdd = "Activate " & i
            hs.DeviceVSP_AddPair(ref, MyVSP)
        Next

        For i = 1 To 64
            MyVSP = New VSPair(ePairStatusControl.Both)
            MyVSP.PairType = VSVGPairType.SingleValue
            MyVSP.Value = -i
            MyVSP.Status = "Learn " & i
            MyVSP.Render = Enums.CAPIControlType.Single_Text_from_List
            MyVSP.StringListAdd = "Learn " & i
            hs.DeviceVSP_AddPair(ref, MyVSP)
        Next


        If ExistingPollButton Then
            dv.Status_Support(hs) = True
            RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumRootActions.Poll, enumRootActions.Poll.ToString, 1, 3)
            If RtnMsg <> "" Then Return RtnMsg
        End If

        dv.Relationship(hs) = Enums.eRelationship.Parent_Root

        dv = Nothing

        Return ""
    End Function

    ' Devices below are a complete set of devices for a motion sensor
#Region "Motion Sensor Group Creation"
    Friend Function CreateMotionSensorGroup(Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim MotionRoot As Integer = CreateMotionSensorRootDevice(ExistingDeviceRef)
        If MotionRoot = -1 Then Return "Can't create MotionRoot device"
        If ExistingDeviceRef = -1 Then
            CreateMotionOccupancyDevice(MotionRoot)
            CreateLuxLevelDevice(MotionRoot)
        End If
        Return 0
    End Function
    Friend Function CreateMotionSensorRootDevice(Optional ByVal ExistingDeviceRef As Integer = -1) As Integer
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            dv = hs.GetDeviceByRef(ref)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            dv = hs.GetDeviceByRef(ref)
            dv.Address(hs) = AddressMotionSensorRootDevice()
            dv.Name(hs) = TypeMotionSensorRoot
            dv.Location(hs) = IFACE_NAME
            dv.Location2(hs) = IFACE_NAME
            'dv.Last_Change(hs) = Now
        End If

        dv.Device_Type_String(hs) = IFACE_NAME & TypeMotionSensorRoot

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceType_GenericRoot
        DT.Device_SubType_Description = "Motion Sensor Root Device"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.NO_STATUS_DISPLAY)

        hs.DeviceVSP_ClearAll(ref, True)
        hs.DeviceVGP_ClearAll(ref, True)

        dv.Relationship(hs) = Enums.eRelationship.Parent_Root

        dv = Nothing

        Return ref
    End Function
    Friend Function CreateMotionOccupancyDevice(ByVal MotionRoot As Integer, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            dv = hs.GetDeviceByRef(ref)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            dv = hs.GetDeviceByRef(ref)
            dv.Address(hs) = AddressMotionOccupancyDevice()
            dv.Name(hs) = TypeMotionOccupancy
            dv.Location(hs) = IFACE_NAME
            dv.Location2(hs) = IFACE_NAME
            hs.SetDeviceValueByRef(ref, enumMotionOccupancyActions.Unknown, True)
            dv.Last_Change(hs) = Now
        End If

        dv.Device_Type_String(hs) = IFACE_NAME & TypeMotionOccupancy

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceAPI.Plug_In

        DT.Device_SubType_Description = "KNX Occupancy Device"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        Dim ExistingPollButton As Boolean = False
        If ExistingDeviceRef <> -1 Then ExistingPollButton = PollExists(ExistingDeviceRef)

        hs.DeviceVSP_ClearAll(ref, True)
        hs.DeviceVGP_ClearAll(ref, True)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, enumMotionOccupancyActions.Unknown, enumMotionOccupancyActions.Unknown.ToString, 0, 0)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, enumMotionOccupancyActions.Occupied, enumMotionOccupancyActions.Occupied.ToString.Replace("_", " "), 1, 1)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, enumMotionOccupancyActions.Not_Occupied, enumMotionOccupancyActions.Not_Occupied.ToString.Replace("_", " "), 1, 2)
        If RtnMsg <> "" Then Return RtnMsg

        Dim GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = enumMotionOccupancyActions.Occupied
        GPair.Graphic = "/images/HomeSeer/status/motion.gif"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = enumMotionOccupancyActions.Not_Occupied
        GPair.Graphic = "/images/HomeSeer/status/nomotion.gif"
        hs.DeviceVGP_AddPair(ref, GPair)

        If ExistingPollButton Then
            dv.Status_Support(hs) = True
            RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumRootActions.Poll, enumRootActions.Poll.ToString, 1, 1)
            If RtnMsg <> "" Then Return RtnMsg
        End If

        If ExistingDeviceRef = -1 Then ' This is not an update to existing device so 
            dv.Relationship(hs) = Enums.eRelationship.Child
            dv.AssociatedDevice_Add(hs, MotionRoot)
            Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
            RootDev = hs.GetDeviceByRef(MotionRoot)
            RootDev.AssociatedDevice_Add(hs, ref)
            RootDev = Nothing
        End If

        dv = Nothing
        Return ""
    End Function
    Friend Function CreateLuxLevelDevice(ByVal MotionRoot As Integer, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            dv = hs.GetDeviceByRef(ref)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            dv = hs.GetDeviceByRef(ref)
            dv.Address(hs) = AddressLuxLevelDevice()
            dv.Name(hs) = TypeLuxLevel
            dv.Location(hs) = IFACE_NAME
            dv.Location2(hs) = IFACE_NAME
            hs.SetDeviceValueByRef(ref, enumKNXActions.Unknown, True)
            dv.Last_Change(hs) = Now
        End If

        dv.Device_Type_String(hs) = IFACE_NAME & TypeLuxLevel

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceAPI.Plug_In

        DT.Device_SubType_Description = "KNX Lux Level Device"
        dv.DeviceType_Set(hs) = DT

        Dim ExistingPollButton As Boolean = False
        If ExistingDeviceRef <> -1 Then ExistingPollButton = PollExists(ExistingDeviceRef)

        hs.DeviceVSP_ClearAll(ref, True)
        hs.DeviceVGP_ClearAll(ref, True)

        Dim MyVSP As New VSPair(ePairStatusControl.Status)
        MyVSP.PairType = VSVGPairType.Range
        MyVSP.Render_Location.Row = 0
        MyVSP.Render_Location.Column = 0
        MyVSP.IncludeValues = True
        MyVSP.RangeStart = 0
        MyVSP.RangeEnd = 670760
        MyVSP.RangeStatusSuffix = " lux"
        MyVSP.RangeStatusDecimals = 1
        MyVSP.Render = Enums.CAPIControlType.ValuesRange
        hs.DeviceVSP_AddPair(ref, MyVSP)
        If Not hs.DeviceVSP_AddPair(ref, MyVSP) Then
            WriteLog(ErrorLog, "VSPair could not be added for device, ref: " & ref.ToString, 0)
            Return "VSPair could not be added for device, ref: " & ref.ToString
        End If

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, enumKNXActions.Unknown, enumKNXActions.Unknown.ToString, 0, 0)
        If RtnMsg <> "" Then Return RtnMsg

        Dim GPair = New VGPair
        GPair.PairType = VSVGPairType.Range
        GPair.RangeStart = 0
        GPair.RangeEnd = 670760
        GPair.Graphic = "/images/HomeSeer/status/luminance-100.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        If ExistingPollButton Then
            dv.Status_Support(hs) = True
            RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumRootActions.Poll, enumRootActions.Poll.ToString, 1, 1)
            If RtnMsg <> "" Then Return RtnMsg
        End If

        If ExistingDeviceRef = -1 Then ' This is not an update to existing device so 
            dv.Relationship(hs) = Enums.eRelationship.Child
            dv.AssociatedDevice_Add(hs, MotionRoot)
            Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
            RootDev = hs.GetDeviceByRef(MotionRoot)
            RootDev.AssociatedDevice_Add(hs, ref)
            RootDev = Nothing
        End If

        dv = Nothing
        Return ""
    End Function

#End Region

    ' Devices below are for a complete set of devices for a Thermostat. In addition the general Temperature Sensor device is also used
#Region "Thermostat Group Creation"
    Friend Function CreateThermostatGroup(Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim TStatRoot As Integer = CreateTStatRootDevice(ExistingDeviceRef)
        If TStatRoot = -1 Then Return "Can't create Thermostat Root device"
        If ExistingDeviceRef = -1 Then
            CreateTStatTemperatureDevice(TStatRoot)
            CreateTStatSetPointDevice(TStatRoot)
            CreateTStatHeatingValveDevice(TStatRoot)
            CreateTSTatHVACModeDevice(TStatRoot)
        End If
        Return 0
    End Function
    Friend Function CreateTStatRootDevice(Optional ByVal ExistingDeviceRef As Integer = -1) As Integer
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            dv = hs.GetDeviceByRef(ref)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            dv = hs.GetDeviceByRef(ref)
            dv.Address(hs) = AddressTStatRootDevice()
            dv.Name(hs) = TypeTStatRoot
            dv.Location(hs) = IFACE_NAME
            dv.Location2(hs) = IFACE_NAME
        End If

        dv.Device_Type_String(hs) = IFACE_NAME & TypeTStatRoot

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Thermostat
        DT.Device_Type = DeviceTypeInfo.eDeviceType_Thermostat.Root
        DT.Device_SubType_Description = "Thermostat Root Device"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.NO_STATUS_DISPLAY)

        hs.DeviceVSP_ClearAll(ref, True)
        hs.DeviceVGP_ClearAll(ref, True)

        dv.Relationship(hs) = Enums.eRelationship.Parent_Root

        dv = Nothing

        Return ref
    End Function
    Friend Function CreateTStatSetPointDevice(ByVal TStatRoot As Integer, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            dv = hs.GetDeviceByRef(ref)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            dv = hs.GetDeviceByRef(ref)
            dv.Address(hs) = AddressTStatSetPointDevice()
            dv.Name(hs) = TypeTStatSetPoint
            dv.Location(hs) = IFACE_NAME
            dv.Location2(hs) = IFACE_NAME
            hs.SetDeviceValueByRef(ref, enumKNXActions.Unknown, True)
            dv.Last_Change(hs) = Now
        End If

        dv.Device_Type_String(hs) = IFACE_NAME & TypeTStatSetPoint

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Thermostat
        DT.Device_Type = DeviceTypeInfo.eDeviceType_Thermostat.Setpoint

        DT.Device_SubType_Description = "KNX Set Point Device"
        dv.DeviceType_Set(hs) = DT

        Dim ExistingPollButton As Boolean = False
        If ExistingDeviceRef <> -1 Then ExistingPollButton = PollExists(ExistingDeviceRef)

        hs.DeviceVSP_ClearAll(ref, True)
        hs.DeviceVGP_ClearAll(ref, True)

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, enumKNXActions.Unknown, enumKNXActions.Unknown.ToString, 0, 0)
        If RtnMsg <> "" Then Return RtnMsg

        Dim MyVSP As New VSPair(ePairStatusControl.Both)
        MyVSP.PairType = VSVGPairType.Range
        MyVSP.Render_Location.Row = 1
        MyVSP.Render_Location.Column = 1
        MyVSP.IncludeValues = True
        MyVSP.RangeStart = 5
        MyVSP.RangeEnd = 35
        MyVSP.RangeStatusSuffix = VSPair.ScaleReplace
        MyVSP.HasScale = True
        MyVSP.Render = Enums.CAPIControlType.ValuesRange
        MyVSP.ControlUse = ePairControlUse._HeatSetPoint
        hs.DeviceVSP_AddPair(ref, MyVSP)
        If Not hs.DeviceVSP_AddPair(ref, MyVSP) Then
            WriteLog(ErrorLog, "VSPair could not be added for device, ref: " & ref.ToString, 0)
            Return "VSPair could not be added for device, ref: " & ref.ToString
        End If

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumTStatSetPointActions.Decrease, "Decrease", 1, 2)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumTStatSetPointActions.Increase, "Increase", 1, 3)
        If RtnMsg <> "" Then Return RtnMsg

        Dim GPair = New VGPair
        GPair.PairType = VSVGPairType.Range
        GPair.RangeStart = -120
        GPair.RangeEnd = 120
        GPair.Graphic = "/images/HomeSeer/status/Thermometer-50.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        If ExistingPollButton Then
            dv.Status_Support(hs) = True
            RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumRootActions.Poll, enumRootActions.Poll.ToString, 1, 1)
            If RtnMsg <> "" Then Return RtnMsg
        End If

        If ExistingDeviceRef = -1 Then ' This is not an update to existing device so 
            dv.Relationship(hs) = Enums.eRelationship.Child
            dv.AssociatedDevice_Add(hs, TStatRoot)
            Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
            RootDev = hs.GetDeviceByRef(TStatRoot)
            RootDev.AssociatedDevice_Add(hs, ref)
            RootDev = Nothing
        End If

        dv = Nothing
        Return ""
    End Function
    Friend Function CreateTStatTemperatureDevice(ByVal TStatRoot As Integer, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            dv = hs.GetDeviceByRef(ref)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            dv = hs.GetDeviceByRef(ref)
            dv.Address(hs) = AddressTStatTemperatureDevice()
            dv.Name(hs) = TypeTStatTemperature
            dv.Location(hs) = IFACE_NAME
            dv.Location2(hs) = IFACE_NAME
            hs.SetDeviceValueByRef(ref, enumRootActions.Unknown, True)
            dv.Last_Change(hs) = Now
        End If

        dv.Device_Type_String(hs) = IFACE_NAME & TypeTStatTemperature

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Thermostat
        DT.Device_Type = DeviceTypeInfo_m.DeviceTypeInfo.eDeviceType_Thermostat.Temperature
        DT.Device_SubType_Description = "KNX TStat Temperature Device"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        Dim ExistingPollButton As Boolean = False
        If ExistingDeviceRef <> -1 Then ExistingPollButton = PollExists(ExistingDeviceRef)

        hs.DeviceVSP_ClearAll(ref, True)
        hs.DeviceVGP_ClearAll(ref, True)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, enumRootActions.Unknown, enumRootActions.Unknown.ToString, 0, 0)
        If RtnMsg <> "" Then Return RtnMsg

        Dim MyVSP As New VSPair(ePairStatusControl.Status)
        MyVSP.PairType = VSVGPairType.Range
        MyVSP.Render_Location.Row = 1
        MyVSP.Render_Location.Column = 1
        MyVSP.IncludeValues = True
        MyVSP.RangeStart = -120
        MyVSP.RangeEnd = 120
        MyVSP.RangeStatusSuffix = VSPair.ScaleReplace
        MyVSP.HasScale = True
        MyVSP.RangeStatusDecimals = 2
        MyVSP.Render = Enums.CAPIControlType.ValuesRange
        hs.DeviceVSP_AddPair(ref, MyVSP)
        If Not hs.DeviceVSP_AddPair(ref, MyVSP) Then
            WriteLog(ErrorLog, "VSPair could not be added for device, ref: " & ref.ToString, 0)
            Return "VSPair could not be added for device, ref: " & ref.ToString
        End If

        Dim GPair = New VGPair
        GPair.PairType = VSVGPairType.Range
        GPair.RangeStart = -120
        GPair.RangeEnd = 120
        GPair.Graphic = "/images/HomeSeer/status/Thermometer-50.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        If ExistingPollButton Then
            dv.Status_Support(hs) = True
            RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumRootActions.Poll, enumRootActions.Poll.ToString, 1, 1)
            If RtnMsg <> "" Then Return RtnMsg
        End If

        If ExistingDeviceRef = -1 Then ' This is not an update to existing device so 
            dv.Relationship(hs) = Enums.eRelationship.Child
            dv.AssociatedDevice_Add(hs, TStatRoot)
            Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
            RootDev = hs.GetDeviceByRef(TStatRoot)
            RootDev.AssociatedDevice_Add(hs, ref)
            RootDev = Nothing
        End If

        dv = Nothing

        Return ""
    End Function
    Friend Function CreateTStatHeatingValveDevice(ByVal TStatRoot As Integer, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            dv = hs.GetDeviceByRef(ref)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            dv = hs.GetDeviceByRef(ref)
            dv.Address(hs) = AddressTStatHeatingValve()
            dv.Name(hs) = TypeTStatHeatingValve
            dv.Location(hs) = IFACE_NAME
            dv.Location2(hs) = IFACE_NAME
            hs.SetDeviceValueByRef(ref, enumTStatHeatingValveActions.Unknown, True)
            dv.Last_Change(hs) = Now
        End If

        dv.Device_Type_String(hs) = IFACE_NAME & TypeTStatHeatingValve

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceType_GenericRoot
        DT.Device_SubType_Description = "KNX Heating Valve Device"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        Dim ExistingPollButton As Boolean = False
        If ExistingDeviceRef <> -1 Then ExistingPollButton = PollExists(ExistingDeviceRef)

        hs.DeviceVSP_ClearAll(ref, True)
        hs.DeviceVGP_ClearAll(ref, True)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, enumTStatHeatingValveActions.Unknown, enumTStatHeatingValveActions.Unknown.ToString, 0, 0)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, enumTStatHeatingValveActions.Heat, enumTStatHeatingValveActions.Heat.ToString, 1, 1,,, ePairControlUse._On)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, enumTStatHeatingValveActions.Off, enumTStatHeatingValveActions.Off.ToString, 1, 2,,, ePairControlUse._Off)
        If RtnMsg <> "" Then Return RtnMsg

        If ExistingPollButton Then
            dv.Status_Support(hs) = True
            RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumRootActions.Poll, enumRootActions.Poll.ToString, 1, 3)
            If RtnMsg <> "" Then Return RtnMsg
        End If

        If ExistingDeviceRef = -1 Then ' This is not an update to existing device so 
            dv.Relationship(hs) = Enums.eRelationship.Child
            dv.AssociatedDevice_Add(hs, TStatRoot)
            Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
            RootDev = hs.GetDeviceByRef(TStatRoot)
            RootDev.AssociatedDevice_Add(hs, ref)
            RootDev = Nothing
        End If

        dv = Nothing

        Return ""
    End Function
    Friend Function CreateTSTatHVACModeDevice(ByVal TStatRoot As Integer, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            dv = hs.GetDeviceByRef(ref)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            dv = hs.GetDeviceByRef(ref)
            dv.Address(hs) = AddressTStatHVACMode()
            dv.Name(hs) = TypeTStatHVACMode
            dv.Location(hs) = IFACE_NAME
            dv.Location2(hs) = IFACE_NAME
            hs.SetDeviceValueByRef(ref, enumRootActions.Unknown, True)
            dv.Last_Change(hs) = Now
        End If

        dv.Device_Type_String(hs) = IFACE_NAME & TypeTStatHVACMode

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Thermostat
        DT.Device_Type = DeviceTypeInfo_m.DeviceTypeInfo.eDeviceType_Thermostat.Mode_Set
        DT.Device_SubType_Description = "KNX TStat HVAC Mode Device"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        Dim ExistingPollButton As Boolean = False
        If ExistingDeviceRef <> -1 Then ExistingPollButton = PollExists(ExistingDeviceRef)

        hs.DeviceVSP_ClearAll(ref, True)
        hs.DeviceVGP_ClearAll(ref, True)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, enumRootActions.Unknown, enumRootActions.Unknown.ToString, 0, 0)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumTStatHVACModeActions.Next, enumTStatHVACModeActions.Next.ToString, 1, 1)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumTStatHVACModeActions.Previous, enumTStatHVACModeActions.Previous.ToString, 1, 2)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, enumTStatHVACModeActions.Auto, enumTStatHVACModeActions.Auto.ToString, 2, 1)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, enumTStatHVACModeActions.Comfort, enumTStatHVACModeActions.Comfort.ToString, 2, 2)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, enumTStatHVACModeActions.Standby, enumTStatHVACModeActions.Standby.ToString, 2, 3)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, enumTStatHVACModeActions.Economy, enumTStatHVACModeActions.Economy.ToString, 3, 1)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, enumTStatHVACModeActions.Building_Protection, enumTStatHVACModeActions.Building_Protection.ToString.Replace("_", " "), 3, 2)
        If RtnMsg <> "" Then Return RtnMsg

        Dim GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = enumTStatHVACModeActions.Auto
        GPair.Graphic = "/images/HomeSeer/status/auto-mode.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = enumTStatHVACModeActions.Comfort
        GPair.Graphic = "/images/HomeSeer/status/home.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = enumTStatHVACModeActions.Standby
        GPair.Graphic = "/images/HomeSeer/status/away.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = enumTStatHVACModeActions.Economy
        GPair.Graphic = "/images/HomeSeer/status/cool.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = enumTStatHVACModeActions.Building_Protection
        GPair.Graphic = "/images/HomeSeer/status/armed-away.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        If ExistingPollButton Then
            dv.Status_Support(hs) = True
            RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, enumRootActions.Poll, enumRootActions.Poll.ToString, 1, 1)
            If RtnMsg <> "" Then Return RtnMsg
        End If

        If ExistingDeviceRef = -1 Then ' This is not an update to existing device so 
            dv.Relationship(hs) = Enums.eRelationship.Child
            dv.AssociatedDevice_Add(hs, TStatRoot)
            Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
            RootDev = hs.GetDeviceByRef(TStatRoot)
            RootDev.AssociatedDevice_Add(hs, ref)
            RootDev = Nothing
        End If

        dv = Nothing

        Return ""
    End Function
#End Region
#End Region

#Region "Device Initiation"
    Public Function InitiateLightBinaryList(Optional ByVal DeviceRef As Integer = -1) As List(Of KNXGroupAddresPair)
        Dim TempList As New List(Of KNXGroupAddresPair)
        Dim TempEntry As New KNXGroupAddresPair
        TempEntry.dvRef = DeviceRef
        TempEntry.Name = "Light On/Off"
        TempEntry.Action = enumKNXActions.Write
        TempEntry.DPT = enumDataPointTypes.Switch
        TempList.Add(TempEntry)

        Return (TempList)
    End Function
    Public Function InitiateLightDimmerList(Optional ByVal DeviceRef As Integer = -1) As List(Of KNXGroupAddresPair)
        Dim TempList As New List(Of KNXGroupAddresPair)
        Dim TempEntry As New KNXGroupAddresPair
        TempEntry.dvRef = DeviceRef

        TempEntry.Name = "Light On/Off"
        TempEntry.Action = enumKNXActions.Write
        TempEntry.DPT = enumDataPointTypes.Switch
        TempList.Add(TempEntry)

        TempEntry = New KNXGroupAddresPair
        TempEntry.Name = "Feedback On/Off"
        TempEntry.Action = enumKNXActions.Feedback_On_Off
        TempEntry.DPT = enumDataPointTypes.Switch
        TempList.Add(TempEntry)

        TempEntry = New KNXGroupAddresPair
        TempEntry.Name = "Feedback Percentage"
        TempEntry.Action = enumKNXActions.Feedback_Percentage
        TempEntry.DPT = enumDataPointTypes.Scaling
        TempList.Add(TempEntry)

        TempEntry = New KNXGroupAddresPair
        TempEntry.Name = "Absolute Dim Value"
        TempEntry.Action = enumKNXActions.AbsoluteDim
        TempEntry.DPT = enumDataPointTypes.Scaling
        TempList.Add(TempEntry)

        TempEntry = New KNXGroupAddresPair
        TempEntry.Name = "Start/Stop Dim/Brighten"
        TempEntry.Action = enumKNXActions.Start_Stop_Dim
        TempEntry.DPT = enumDataPointTypes.Dimming_Control
        TempList.Add(TempEntry)

        Return (TempList)
    End Function
    Friend Function InitiateTemperatureSensorList(Optional ByVal DeviceRef As Integer = -1) As List(Of KNXGroupAddresPair)
        Dim TempList As New List(Of KNXGroupAddresPair)
        Dim TempEntry As New KNXGroupAddresPair
        TempEntry.dvRef = DeviceRef
        TempEntry.Name = "Temperature"
        TempEntry.Action = enumKNXActions.Feedback_Value
        TempEntry.DPT = enumDataPointTypes.Value_Temp
        TempList.Add(TempEntry)

        Return (TempList)
    End Function
    Public Function InitiateMotionOccupancyList(Optional ByVal DeviceRef As Integer = -1) As List(Of KNXGroupAddresPair)
        Dim TempList As New List(Of KNXGroupAddresPair)
        Dim TempEntry As New KNXGroupAddresPair
        TempEntry.dvRef = DeviceRef
        TempEntry.Name = "Occupancy"
        TempEntry.Action = enumKNXActions.Write
        TempEntry.DPT = enumDataPointTypes.Switch
        TempList.Add(TempEntry)

        Return (TempList)
    End Function
    Public Function InitiateLuxLevelList(Optional ByVal DeviceRef As Integer = -1) As List(Of KNXGroupAddresPair)
        Dim TempList As New List(Of KNXGroupAddresPair)
        Dim TempEntry As New KNXGroupAddresPair
        TempEntry.dvRef = DeviceRef

        TempEntry = New KNXGroupAddresPair
        TempEntry.Name = "Lux Level"
        TempEntry.Action = enumKNXActions.Feedback_Value
        TempEntry.DPT = enumDataPointTypes.Value_Lux
        TempList.Add(TempEntry)

        Return (TempList)
    End Function
    Public Function InitiateBlindCurtainList(Optional ByVal DeviceRef As Integer = -1) As List(Of KNXGroupAddresPair)
        Dim TempList As New List(Of KNXGroupAddresPair)
        Dim TempEntry As New KNXGroupAddresPair
        TempEntry.dvRef = DeviceRef

        TempEntry.Name = "Open/Close"
        TempEntry.Action = enumKNXActions.Write
        TempEntry.DPT = enumDataPointTypes.Switch
        TempList.Add(TempEntry)

        TempEntry = New KNXGroupAddresPair
        TempEntry.Name = "Position Feedback"
        TempEntry.Action = enumKNXActions.Feedback_Position
        TempEntry.DPT = enumDataPointTypes.Scaling
        TempList.Add(TempEntry)

        TempEntry = New KNXGroupAddresPair
        TempEntry.Name = "Start/Stop Open/Close"
        TempEntry.Action = enumKNXActions.Start_Stop_Dim
        TempEntry.DPT = enumDataPointTypes.Blind_Control
        TempList.Add(TempEntry)

        Return (TempList)
    End Function
    Public Function InitiateBinarySceneList(Optional ByVal DeviceRef As Integer = -1) As List(Of KNXGroupAddresPair)
        Dim TempList As New List(Of KNXGroupAddresPair)
        Dim TempEntry As New KNXGroupAddresPair
        TempEntry.dvRef = DeviceRef
        TempEntry.Name = "Scene"
        TempEntry.Action = enumKNXActions.Write
        TempEntry.DPT = enumDataPointTypes.Switch
        TempList.Add(TempEntry)

        Return (TempList)
    End Function
    Public Function InitiateSceneList(Optional ByVal DeviceRef As Integer = -1) As List(Of KNXGroupAddresPair)
        Dim TempList As New List(Of KNXGroupAddresPair)
        Dim TempEntry As New KNXGroupAddresPair
        TempEntry.dvRef = DeviceRef
        TempEntry.Name = "Scene"
        TempEntry.Action = enumKNXActions.Write
        TempEntry.DPT = enumDataPointTypes.Scene_Control
        TempList.Add(TempEntry)

        Return (TempList)
    End Function
    Friend Function InitiateTStatTemperatureList(Optional ByVal DeviceRef As Integer = -1) As List(Of KNXGroupAddresPair)
        Dim TempList As New List(Of KNXGroupAddresPair)
        Dim TempEntry As New KNXGroupAddresPair
        TempEntry.dvRef = DeviceRef
        TempEntry.Name = "Temperature"
        TempEntry.Action = enumKNXActions.Feedback_Value
        TempEntry.DPT = enumDataPointTypes.Value_Temp
        TempList.Add(TempEntry)

        Return (TempList)
    End Function
    Friend Function InitiateTStatSetpointList(Optional ByVal DeviceRef As Integer = -1) As List(Of KNXGroupAddresPair)
        Dim TempList As New List(Of KNXGroupAddresPair)
        Dim TempEntry As New KNXGroupAddresPair
        TempEntry.dvRef = DeviceRef
        TempEntry.Name = "Setpoint"
        TempEntry.Action = enumKNXActions.Write
        TempEntry.DPT = enumDataPointTypes.Value_Temp
        TempList.Add(TempEntry)

        Return (TempList)
    End Function
    Public Function InitiateTStatHeatingValveList(Optional ByVal DeviceRef As Integer = -1) As List(Of KNXGroupAddresPair)
        Dim TempList As New List(Of KNXGroupAddresPair)
        Dim TempEntry As New KNXGroupAddresPair
        TempEntry.dvRef = DeviceRef
        TempEntry.Name = "Heating On/Off"
        TempEntry.Action = enumKNXActions.Write
        TempEntry.DPT = enumDataPointTypes.Switch
        TempList.Add(TempEntry)

        Return (TempList)
    End Function
    Public Function InitiateTStatHVACModeList(Optional ByVal DeviceRef As Integer = -1) As List(Of KNXGroupAddresPair)
        Dim TempList As New List(Of KNXGroupAddresPair)
        Dim TempEntry As New KNXGroupAddresPair
        TempEntry.dvRef = DeviceRef
        TempEntry.Name = "Mode"
        TempEntry.Action = enumKNXActions.Write
        TempEntry.DPT = enumDataPointTypes.HVAC_Mode
        TempList.Add(TempEntry)

        Return (TempList)
    End Function
#End Region

#Region "izKNX Procedures and Functions"
    Friend Sub InvalidControlValue(ByVal dvRef As Integer, ByVal AdrLookup As String, ByVal ControlValue As Integer)
        WriteLog(ErrorLog, "SetIOMulti called with invalid parameters, DeviceRef: " & dvRef & " Device: " & AdrLookup & " Value: " & ControlValue, 0)
    End Sub
    Friend Function PullPEDData(ByVal dvRef As Integer) As List(Of KNXGroupAddresPair) 'Object
        Try
            Dim dv As Scheduler.Classes.DeviceClass = Nothing
            dv = hs.GetDeviceByRef(dvRef)

            Dim DeviceType As String = dv.Device_Type_String(Nothing)
            DeviceType = Right(DeviceType, DeviceType.Length - IFACE_NAME.Length)

            If DeviceType = TypeKNXRoot Then Return Nothing ' Nothing to configure on this device
            Dim PED As clsPlugExtraData = dv.PlugExtraData_Get(hs)

            If PED Is Nothing Then Return Nothing ' No GroupAddresses setup

            Dim KNXpairs As New List(Of KNXGroupAddresPair)
            KNXpairs = PEDGet(PED, PEDName)
            Return KNXpairs
        Catch
            WriteLog(ErrorLog, Err.Description, 0)
            Return Nothing
        End Try
    End Function
    Friend Function BuildGATable() As IList(Of KNXGroupAddresPair)
        Dim CompleteList As New List(Of KNXGroupAddresPair)
        Dim GroupAddressCount As Integer = 0 ' Total number of GroupAddresses in table. Used for licensing restrictions

        Try
            Dim dv As Scheduler.Classes.DeviceClass
            Dim EN As Scheduler.Classes.clsDeviceEnumeration
            EN = hs.GetDeviceEnumerator
            If EN Is Nothing Then
                WriteLog(ErrorLog, "Error getting Enumerator in izInit", 0)
                Return Nothing
            End If
            Do
                dv = EN.GetNext
                If dv Is Nothing Then Continue Do
                If dv.Interface(Nothing) = IFACE_NAME Then ' One of ours
                    Dim dvRef As Integer = dv.Ref(Nothing)

                    Dim KNXPairs As New List(Of KNXGroupAddresPair)
                    Try ' Try is needed as PullGroupAddress will return Nothing when none are setup which will cause the below line to error
                        KNXPairs = PullPEDData(dv.Ref(Nothing))

                        For Each GA In KNXPairs
                            If GA IsNot Nothing Then
                                Dim GAPair As New KNXGroupAddresPair
                                GAPair.dvRef = dvRef
                                GAPair.Action = GA.Action
                                GAPair.GroupAddress = GA.GroupAddress
                                GAPair.Name = GA.Name
                                GAPair.DPT = GA.DPT
                                GAPair.PollMe = GA.PollMe
                                CompleteList.Add(GAPair)
                                GroupAddressCount = CompleteList.Count

                                If LicenseType = LicenseBasic Then
                                    If GroupAddressCount > LicenseBasicCount Then
                                        WriteLog(ErrorLog, "The " & LicenseBasic & " version supports a maximum of " & LicenseBasicCount & " Group Addresses. Please upgrade if you need to use more Group Addresses", 0)
                                        Return CompleteList
                                    End If
                                End If

                                If LicenseType = LicensePremium Then
                                    If GroupAddressCount > LicensePremiumCount Then
                                        WriteLog(ErrorLog, "The " & LicensePremium & " version supports a maximum of " & LicensePremiumCount & " Group Addresses. Please upgrade if you need to use more Group Addresses", 0)
                                        Return CompleteList
                                    End If
                                End If

                            End If
                        Next
                    Catch ex As Exception

                    End Try
                End If
            Loop Until EN.Finished
        Catch ex As Exception
            hs.WriteLog("Error", "Exception in device enumeration: " & ex.Message)
            Return Nothing
        End Try
        CompleteList.Sort(Function(x, y) x.GroupAddress.CompareTo(y.GroupAddress))
        WriteLog(InfoLog, "Plug-in has " & GroupAddressCount & " Group Addresses configured", 0)
        Return CompleteList
    End Function
    Friend Function BuildDPTList() As List(Of HomeSeerAPI.Pair)
        Try
            Dim CompleteList As New List(Of HomeSeerAPI.Pair)

            Dim names = [Enum].GetNames(GetType(enumDataPointTypes))
            Dim values = [Enum].GetValues(GetType(enumDataPointTypes))
            Dim i As Integer = 0
            For Each name In names
                Dim DPTPair As New HomeSeerAPI.Pair
                DPTPair.Value = values(i)
                Dim Value As Integer = values(i)
                Dim ValueString As String = Value.ToString
                DPTPair.Name = name.Replace("_", " ") & " (" & Left(ValueString, ValueString.Length - 3) & "." & Right(ValueString, 3) & ")"
                CompleteList.Add(DPTPair)
                i += 1
            Next
            Return CompleteList
        Catch ex As Exception
            WriteLog(ErrorLog, ex.Message, 0)
            Return Nothing
        End Try
    End Function
    Friend Function BuildActionPairList() As List(Of HomeSeerAPI.Pair)
        Try
            Dim CompleteList As New List(Of HomeSeerAPI.Pair)

            Dim names = [Enum].GetNames(GetType(enumKNXActions))
            Dim values = [Enum].GetValues(GetType(enumKNXActions))
            Dim i As Integer = 0
            For Each name In names
                Dim ActPair As New HomeSeerAPI.Pair
                ActPair.Name = name.Replace("_", " ")
                ActPair.Value = values(i)
                CompleteList.Add(ActPair)
                i += 1
            Next
            Return CompleteList
        Catch ex As Exception
            WriteLog(ErrorLog, ex.Message, 0)
            Return Nothing
        End Try
    End Function
    Friend Function FindDeviceGroupAddress(ByVal dvRef As Integer, ByVal Action As enumKNXActions, Optional ByVal Polling As Boolean = False) As String
        Dim GAEntry As New List(Of KNXGroupAddresPair)
        GAEntry = GroupAddressTable.FindAll(Function(p) p.dvRef = dvRef)
        For Each Entry In GAEntry
            If Polling And Entry.PollMe Then
                Return Entry.GroupAddress
            Else
                If Entry.Action = Action Then Return Entry.GroupAddress
            End If
        Next
        If Not Polling Then
            WriteLog(ErrorLog, "Action: " & Action & " not found for device: " & dvRef, 0)
        Else
            WriteLog(DebugLog, "No Group Address enabled for Polling on device: " & dvRef, 3)
        End If

        Return ""
    End Function
    Friend Function FindDeviceGADPT(ByVal dvRef As Integer, ByVal GroupAddress As String) As Integer
        Dim GAEntry As New List(Of KNXGroupAddresPair)
        GAEntry = GroupAddressTable.FindAll(Function(p) p.dvRef = dvRef)
        For Each Entry In GAEntry
            If Entry.GroupAddress = GroupAddress Then Return Entry.DPT
        Next

        WriteLog(ErrorLog, "Group Address: " & GroupAddress & " not found for device: " & dvRef, 0)
        Return 0
    End Function
    Friend Function ValidateGroupAddress(ByVal GA As String) As String
        Dim chrGA() As Char = GA.ToCharArray
        For Each Entry In chrGA
            If Not InStr("0123456789/", Entry) > 0 Then
                Return "Invalid characters in Group Address"
            End If
        Next
        Dim GAArray() As String = GA.Split("/")
        Select Case _GroupAddressStructure
            Case 1
                Dim intGA As Integer = Val(GA)
                If intGA < 0 Then Return "Group Address can't be a negative number"
                If intGA > 65535 Then Return "Group Address can't be greater than 65535"
            Case 2
                If GAArray.Length <> 2 Then Return "Group Address is 2-level and must be in the format main/sub (0..31/0..2047)"
                If Val(GAArray(0)) < 0 Or Val(GAArray(1)) < 0 Then Return "Group Address can't contain negative numbers"
                If Val(GAArray(0)) > 31 Then Return "Main Group must be in the range 0..31"
                If Val(GAArray(1)) > 2047 Then Return "Sub Group must be in the range 0..2047"
            Case 3
                If GAArray.Length <> 3 Then Return "Group Address is 3-level and must be in the format main/middle/sub (0..31/0..7/0..255)"
                If Val(GAArray(0)) < 0 Or Val(GAArray(1)) < 0 Or Val(GAArray(2)) < 0 Then Return "Group Address can't contain negative numbers"
                If Val(GAArray(0)) > 31 Then Return "Main Group must be in the range 0..31"
                If Val(GAArray(1)) > 7 Then Return "Middle Group must be in the range 0..7"
                If Val(GAArray(2)) > 255 Then Return "Sub Group must be in the range 0..255"
        End Select
        Return ""
    End Function
#End Region

#Region "KNX Encode/Decode Functions"
    Friend Function DecodeDimValue(ByVal RawValue As Integer) As Integer
        Dim DimValue As Integer = Int((RawValue + 1) / 255 * 100)
        If DimValue = 99 Then DimValue = 100
        Return DimValue
    End Function
    Friend Function DecodeTempValue(ByVal RawValueMSB As Byte, ByVal RawValueLSB As Byte) As Double
        Dim TempValue As Double = KNXMantissaDecode(RawValueMSB, RawValueLSB)
        Return TempValue
    End Function
    Friend Function DecodeLuxValue(ByVal RawValueMSB As Byte, ByVal RawValueLSB As Byte) As Double
        Dim LuxLevel As Double = KNXMantissaDecode(RawValueMSB, RawValueLSB)
        Return LuxLevel
    End Function
    Friend Function EncodeDimValue(ByVal RawValuePercent As Integer) As Integer
        Return Int(RawValuePercent / 100 * 255)
    End Function
    Friend Function EncodeDimStep(ByVal Increase As Boolean, Optional ByVal DimStep As Integer = _DimStepValue) As FourBit
        Dim TempValue As Integer = 0
        TempValue = DimStep
        If Increase Then TempValue = TempValue + 8

        EncodeDimStep = New FourBit(TempValue)
        Return EncodeDimStep
    End Function
    Friend Function DecodeDimStep(ByVal RawValue As Integer) As Integer
        If RawValue = 0 Then Return enumDimmerActions.Stop_Dim_Action
        If RawValue <= 9 Then Return enumDimmerActions.Start_Brighten
        If RawValue >= 9 Then Return enumDimmerActions.Start_Dimming
        Return -1
    End Function
    Friend Function DecodeSceneValue(ByVal RawValue As Byte) As Integer
        Dim Activate As Boolean = True
        RawValue += 1  ' Adjust for the fact that in HS3 scenes are 1-64
        If RawValue > 63 Then
            Activate = False
            RawValue = -RawValue - 128
        End If
        Return RawValue
    End Function
    Friend Function EncodeSceneValue(ByVal Scene As Integer, ByVal Activate As Boolean) As Byte
        If Scene < 0 Then Scene = -Scene ' Make it positive as we can only send positive values
        If Not Activate Then Scene += 128
        Scene -= 1  ' Adjust for the fact that in HS3 scenes are 1-64
        Return Scene
    End Function
    Friend Function EncodeFourOctectUnsigned(ByVal Value As Double) As Byte()
        Dim ValueSet(3) As Byte
        ValueSet(3) = Int(Value / 256 / 256 / 256)
        Dim TempValue As Double = Int(Value - ValueSet(3) * 256 * 256 * 256)
        ValueSet(2) = Int(TempValue / 256 / 256)
        TempValue = Int(TempValue - ValueSet(2) * 256 * 256)
        ValueSet(1) = Int(TempValue / 256)
        ValueSet(0) = Int(TempValue - ValueSet(1) * 256)
        Return ValueSet
    End Function
    Friend Function DecodeFourOctetUnsigned(ByVal ValueSet() As Byte) As Double
        Dim TempValue As Double = 0
        TempValue = ValueSet(0) + ValueSet(1) * 256 + ValueSet(2) * 256 * 256 + ValueSet(3) * 256 * 256 * 256
        Return TempValue
    End Function
#End Region

#Region "KNX Communication"
    Friend Function CheckKNXBusConnection() As Boolean
        If _ConnectionKeepAlive And Not KNXBus.IsConnected Then ' Reconnect if required and requested
            KNXSetupConnection()
            If Not KNXBus.IsConnected Then
                WriteLog(ErrorLog, "KNX Bus connection was broken and could not be re-established.", 0)
                Return False
            End If
            Return True
        End If

        Return True
    End Function
    Friend Function UpdateHSDevice(ByVal Data As GroupValue, ByVal KNXGroupAddress As String, Optional ByRef DecodedValue As Double = 0) As Boolean
        Try
            Dim GAEntry As New KNXGroupAddresPair
            GAEntry = GroupAddressTable.Find(Function(p) p.GroupAddress = KNXGroupAddress)
            If GAEntry IsNot Nothing Then
                Dim dv As Scheduler.Classes.DeviceClass = Nothing
                dv = hs.GetDeviceByRef(GAEntry.dvRef)

                Dim ScaleDevice As Boolean = False

                Dim DeviceType As String = dv.Device_Type_String(Nothing)
                DeviceType = Right(DeviceType, DeviceType.Length - IFACE_NAME.Length)

                If DeviceType = TypeKNXRoot Then Return True ' Nothing to update on this device

                Select Case GAEntry.DPT
                    Case 1001, 1002 ' Binary/Boolean
                        DecodedValue = Data.Value(0)
                    Case 3007 ' Start/Stop Dim
                        DecodedValue = DecodeDimStep(Data.Value(0))
                    Case 3008 ' Blind Control
                        ' Not yet implemented
                    Case 5001 ' Dimmer
                        DecodedValue = DecodeDimValue(Data.Value(0))
                    Case 9001 ' Temperature
                        DecodedValue = DecodeTempValue(Data.Value(0), Data.Value(1))
                        ScaleDevice = True
                    Case 9004 ' LuxLevel
                        DecodedValue = DecodeLuxValue(Data.Value(0), Data.Value(1))
                    Case 12001 ' Four Octet Unsigned
                        Dim ValueSet(3) As Byte
                        ValueSet(0) = Data.Value(0)
                        ValueSet(1) = Data.Value(1)
                        ValueSet(2) = Data.Value(2)
                        ValueSet(3) = Data.Value(3)
                        DecodedValue = DecodeFourOctetUnsigned(ValueSet)
                    Case 18001
                        DecodedValue = DecodeSceneValue(Data.Value(0))
                        If DecodedValue < 0 Then Return True ' We do not handle Learns so need to exit here
                    Case enumDataPointTypes.HVAC_Mode ' 20.102
                        DecodedValue = Data.Value(0)
                End Select

                hs.SetDeviceValueByRef(GAEntry.dvRef, DecodedValue, True)
                If ScaleDevice Then dv.ScaleText(hs) = izTemperatureScale

            End If

        Catch ex As Exception
            WriteLog(ErrorLog, "Problem updating HS device. Error message: " & ex.Message, 0)
        End Try

        Return True
    End Function

    ' DELETE BELOW FUNCTION
    Friend Function UpdateHSDeviceOLDX(ByVal data As GroupValueEventArgs) As Boolean
        Try
            Dim GAEntry As New KNXGroupAddresPair
            GAEntry = GroupAddressTable.Find(Function(p) p.GroupAddress = data.Address.ToString)

            If GAEntry IsNot Nothing Then
                Dim dv As Scheduler.Classes.DeviceClass = Nothing
                dv = hs.GetDeviceByRef(GAEntry.dvRef)

                Dim DeviceType As String = dv.Device_Type_String(Nothing)
                DeviceType = Right(DeviceType, DeviceType.Length - IFACE_NAME.Length)

                If DeviceType = TypeKNXRoot Then Return True ' Nothing to configure on this device

                Select Case DeviceType
                    Case TypeBinary
                        Select Case GAEntry.Action
                            Case enumKNXActions.Write
                                hs.SetDeviceValueByRef(GAEntry.dvRef, data.Value.Value(0), True)
                        End Select
                    Case TypeDimmer
                        Select Case GAEntry.Action
                            Case enumKNXActions.Feedback_Percentage
                                hs.SetDeviceValueByRef(GAEntry.dvRef, DecodeDimValue(data.Value.Value(0)), True)
                        End Select
                    Case TypeTemperature
                        Select Case GAEntry.Action
                            Case enumKNXActions.Feedback_Value
                                hs.SetDeviceValueByRef(GAEntry.dvRef, DecodeTempValue(data.Value.Value(0), data.Value.Value(1)), True)
                        End Select
                    Case TypeMotionOccupancy
                        Select Case GAEntry.Action
                            Case enumKNXActions.Write
                                hs.SetDeviceValueByRef(GAEntry.dvRef, data.Value.Value(0), True)
                        End Select
                    Case TypeLuxLevel
                        Select Case GAEntry.Action
                            Case enumKNXActions.Feedback_Value
                                hs.SetDeviceValueByRef(GAEntry.dvRef, DecodeLuxValue(data.Value.Value(0), data.Value.Value(1)), True)
                            Case enumKNXActions.Write
                                hs.SetDeviceValueByRef(GAEntry.dvRef, DecodeLuxValue(data.Value.Value(0), data.Value.Value(1)), True)
                        End Select
                    Case TypeBlindCurtain
                        Select Case GAEntry.Action
                            Case enumKNXActions.Write
                                hs.SetDeviceValueByRef(GAEntry.dvRef, data.Value.Value(0), True)
                        End Select
                End Select

            Else
                WriteLog(WarningLog, "GroupValueReceived from KNX interface for unmanaged Group Address: " & data.Address.ToString, 0)
            End If
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try

        Return True
    End Function
    ' DELETE ABOVE FUNCTION

    Public Sub GroupValueReceivedEvent(ByVal Data As GroupValueEventArgs)
        WriteLog(DebugLog, "=====START: GroupValueReceivedEvent====== at " & Now(), 5)
        WriteLog(DebugLog, "GroupValueReceivedEvent", 5)
        WriteLog(DebugLog, "Adress           : " & Data.Address.ToString, 5)
        WriteLog(DebugLog, "IndividualAddress: " & Data.IndividualAddress.ToString, 5)
        WriteLog(DebugLog, "IsConfirmation   : " & Data.IsConfirmation.ToString, 5)
        WriteLog(DebugLog, "IsRead           : " & Data.IsRead.ToString, 5)
        WriteLog(DebugLog, "IsResponse       : " & Data.IsResponse.ToString, 5)
        WriteLog(DebugLog, "IsSecure         : " & Data.IsSecure.ToString, 5)
        WriteLog(DebugLog, "IsWrite          : " & Data.IsWrite.ToString, 5)
        WriteLog(DebugLog, "TelegramPriority : " & Data.TelegramPriority.ToString, 5)
        WriteLog(DebugLog, "Value            : " & Data.Value.ToString, 5)
        WriteLog(DebugLog, "Actual Value     : " & Data.Value.Value.ToString, 5)
        WriteLog(DebugLog, "==============FINISH=================", 5)

        Dim Result As Boolean = UpdateHSDevice(Data.Value, Data.Address.ToString)

        'Dim Result As Boolean = UpdateHSDeviceFromGroupValueReceived(Data)
    End Sub
    Public Sub GroupValueReadReceivedEvent(ByVal Data As GroupValueEventArgs)
        WriteLog(DebugLog, "===START: GroupValueReadReceivedEvent==== at " & Now(), 3)
        WriteLog(DebugLog, "GroupValueReceivedEvent", 3)
        WriteLog(DebugLog, "Adress           : " & Data.Address.ToString, 3)
        WriteLog(DebugLog, "IndividualAddress: " & Data.IndividualAddress.ToString, 3)
        WriteLog(DebugLog, "IsConfirmation   : " & Data.IsConfirmation.ToString, 3)
        WriteLog(DebugLog, "IsRead           : " & Data.IsRead.ToString, 3)
        WriteLog(DebugLog, "IsResponse       : " & Data.IsResponse.ToString, 3)
        WriteLog(DebugLog, "IsSecure         : " & Data.IsSecure.ToString, 3)
        WriteLog(DebugLog, "IsWrite          : " & Data.IsWrite.ToString, 3)
        WriteLog(DebugLog, "TelegramPriority : " & Data.TelegramPriority.ToString, 3)
        If Data.Value IsNot Nothing Then WriteLog(DebugLog, "Value            : " & Data.Value.ToString, 3)
        If Data.Value IsNot Nothing Then WriteLog(DebugLog, "Actual Value     : " & Data.Value.Value.ToString, 3)
        WriteLog(DebugLog, "==============FINISH=================", 3)

        If Data.IsResponse Then
            Dim Result As Boolean = UpdateHSDevice(Data.Value, Data.Address.ToString)
            'UpdateHSDeviceOLD(Data)
        End If
    End Sub

    Public Sub KNXStateChangeEvent(ByVal Data As BusConnectionStatus)
        WriteLog(WarningLog, "Underlying KNX connector changed. Status is: " & Data.ToString, 0)
        hs.SetDeviceValueByRef(_CurrentKNXRoot, CInt(Data), True)
    End Sub
    Public Sub LocalInterfaceAddressChangedEvent(ByVal Data As IndividualAddress)
        WriteLog(WarningLog, "We got LocalInterfaceChange. Message: " & Data.ToString, 0)
    End Sub
    Friend Sub KNXSetupConnection()
        Try
            KNXBus = New Bus(New KnxIpTunnelingConnectorParameters(IPAddress, Val(KNXPort), UseNAT))
            AddHandler KNXBus.StateChanged, AddressOf KNXStateChangeEvent
            AddHandler KNXBus.GroupValueReceived, AddressOf GroupValueReceivedEvent
            AddHandler KNXBus.GroupValueReadReceived, AddressOf GroupValueReadReceivedEvent
            AddHandler KNXBus.LocalInterfaceAddressChanged, AddressOf LocalInterfaceAddressChangedEvent
            KNXBus.Connect()
        Catch ex As Exception
            WriteLog(ErrorLog, "Problem open KNX Tunnel. Error message: " & ex.Message, 0)
        End Try
    End Sub
    Friend Sub KNXCloseConnection()
        Try
            KNXBus.Disconnect()
            RemoveHandler KNXBus.StateChanged, AddressOf KNXStateChangeEvent
            RemoveHandler KNXBus.GroupValueReceived, AddressOf GroupValueReceivedEvent
            RemoveHandler KNXBus.GroupValueReadReceived, AddressOf GroupValueReadReceivedEvent
        Catch ex As Exception
            WriteLog(ErrorLog, "Problem closing KNX Tunnel. Error message: " & ex.Message, 0)
        End Try
    End Sub
    Friend Sub KNXSendDoubleByte(ByVal GroupAddress As String, ByVal Value As Byte(), Optional ByVal Priority As Priority = Priority.Low)
        Try
            KNXBus.WriteValue(GroupAddress, New GroupValue(Value), Priority)
        Catch ex As Exception
            WriteLog(ErrorLog, "Error sending message to KNX bus. Error message: " & ex.Message, 0)
        End Try
    End Sub
    Friend Sub KNXSendSixBits(ByVal GroupAddress As String, ByVal Value As SixBit, Optional ByVal Priority As Priority = Priority.Low)
        Try
            KNXBus.WriteValue(GroupAddress, New GroupValue(Value), Priority)
        Catch ex As Exception
            WriteLog(ErrorLog, "Error sending message to KNX bus. Error message: " & ex.Message, 0)
        End Try
    End Sub
    Friend Sub KNXSendByte(ByVal GroupAddress As String, ByVal Value As Byte, Optional ByVal Priority As Priority = Priority.Low)
        Try
            KNXBus.WriteValue(GroupAddress, New GroupValue(Value), Priority)
        Catch ex As Exception
            WriteLog(ErrorLog, "Error sending message to KNX bus. Error message: " & ex.Message, 0)
        End Try
    End Sub
    Friend Sub KNXSend4Bit(ByVal GroupAddress As String, ByVal Value As FourBit, Optional ByVal Priority As Priority = Priority.Low)
        Try
            KNXBus.WriteValue(GroupAddress, New GroupValue(Value), Priority)
        Catch ex As Exception
            WriteLog(ErrorLog, "Error sending message to KNX bus. Error message: " & ex.Message, 0)
        End Try
    End Sub
    Friend Sub KNXSendBoolean(ByVal GroupAddress As String, ByVal Value As Boolean, Optional ByVal Priority As Priority = Priority.Low)
        Try
            KNXBus.WriteValue(GroupAddress, New GroupValue(Value), Priority)
        Catch ex As Exception
            WriteLog(ErrorLog, "Error sending message to KNX bus. Error message: " & ex.Message, 0)
        End Try
    End Sub
    Friend Sub KNXSendFourOctectUnsigned(ByVal GroupAddress As String, ByVal Value As Boolean, Optional ByVal Priority As Priority = Priority.Low)
        Try
            KNXBus.WriteValue(GroupAddress, New GroupValue(EncodeFourOctectUnsigned(Value)), Priority)
        Catch ex As Exception
            WriteLog(ErrorLog, "Error sending message to KNX bus. Error message: " & ex.Message, 0)
        End Try
    End Sub
    Friend Function KNXPollDevice(ByVal dvref As Integer, Optional ByVal WarnOnError As Boolean = True) As IPlugInAPI.PollResultInfo
        Dim ReturnVal As New IPlugInAPI.PollResultInfo
        WriteLog(DebugLog, "Starting Poll of device " & dvref, 5)
        ReturnVal.Result = IPlugInAPI.enumPollResult.OK
        ReturnVal.Value = Nothing

        Dim BusValue As UInt32 = 0
        Dim KNXGroupAddress As String = FindDeviceGroupAddress(dvref, enumKNXActions.Unknown, True)

        If KNXGroupAddress <> "" Then
            Try
                WriteLog(DebugLog, "GroupAddress for Read exists, sending Read on KNX bus", 3)
                Dim gv As GroupValue = KNXBus.ReadValue(KNXGroupAddress,, 500)
                Dim Result As Boolean = UpdateHSDevice(gv, KNXGroupAddress, ReturnVal.Value)
                WriteLog(DebugLog, "Bus returned: " & ReturnVal.Value.ToString, 3)
            Catch ex As Exception
                If WarnOnError Then
                    WriteLog(ErrorLog, "Error reading Group Address: " & KNXGroupAddress & " Error Message: " & ex.Message, 0)
                Else
                    WriteLog(ErrorLog, "Error reading Group Address: " & KNXGroupAddress & " Error Message: " & ex.Message, 5)
                End If
                ReturnVal.Result = IPlugInAPI.enumPollResult.Error_Getting_Status
            End Try
        Else
            If WarnOnError Then
                WriteLog(WarningLog, "Read Group Address not defined for device", 0)
            Else
                WriteLog(WarningLog, "Read Group Address not defined for device", 5)
            End If
            ReturnVal.Result = IPlugInAPI.enumPollResult.Other_Error
        End If

        Return ReturnVal
    End Function

    Friend Sub EncodeAndSend(ByVal GroupAddress As String, ByVal Value As Integer, ByVal DPT As Integer)
        Select Case DPT
            Case enumDataPointTypes.Switch ' 1.001
                Dim Command As Boolean = Value = enumBinaryActions.On
                KNXSendBoolean(GroupAddress, Command)
            Case enumDataPointTypes.Boolean ' 1.002
                Dim Command As Boolean = Value = enumBinaryActions.On
                KNXSendBoolean(GroupAddress, Command)
            'Case enumDataPointTypes.Dimming_Control ' 3.007
            'Case enumDataPointTypes.Blind_Control ' 3.008
            'Case enumDataPointTypes.Scaling ' 5.001
            Case enumDataPointTypes.Value_Temp ' 9.001
                KNXSendDoubleByte(GroupAddress, KNXMantissaEncode(Value))
                'Case enumDataPointTypes.Value_Lux ' 9.004
                'Case enumDataPointTypes.Scene_Control ' 18.001
            Case enumDataPointTypes.FourOctet_Unsigned
                KNXSendFourOctectUnsigned(GroupAddress, Value)
            Case enumDataPointTypes.HVAC_Mode ' 20.102
                KNXSendByte(GroupAddress, Value)
            Case Else ' DPT not defined
                WriteLog(ErrorLog, "Encode function not defined for DPT " & DPT, 0)
        End Select

    End Sub
#End Region

End Module
