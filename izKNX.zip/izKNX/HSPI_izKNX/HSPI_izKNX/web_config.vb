﻿Imports System.Text
Imports System.Web
Imports Scheduler
Imports HomeSeerAPI

Public Class web_config
    Inherits clsPageBuilder
    Dim TimerEnabled As Boolean

    Dim sDebugLevel As String = ""
    Dim sConsole As String = ""

    Dim sTimerBasedPoll As Boolean = False
    Dim sUseEventCallBack As Boolean = False
    Dim sPollingFrequency As String = ""

    Dim sIncludeLocation1 As Boolean = True
    Dim sIncludeLocation2 As Boolean = True

    Dim KNXDeviceTypes() As String = {"Binary Light", "Dimnmer", "Temperature Sensor", "Motion Sensor", "Blind/Curtain", "Binary Scene", "Scene Device", "Thermostat"}
    Dim KNXCreationCount(KNXDeviceTypes.Length) As Integer

    Public Sub New(ByVal pagename As String)
        MyBase.New(pagename)
    End Sub

    Public Overrides Function postBackProc(page As String, data As String, user As String, userRights As Integer) As String

        Dim parts As Collections.Specialized.NameValueCollection
        parts = HttpUtility.ParseQueryString(data)
        Select Case parts("id")
            Case "oIPAddress"
                KNXCloseConnection()
                IPAddress = parts("IPAddress").Trim
                KNXSetupConnection()
            Case "oKNXPort"
                KNXCloseConnection()
                KNXPort = parts("KNXPort").Trim
                KNXSetupConnection()
            Case "oUseNAT"
                KNXCloseConnection()
                If parts("UseNAT").ToLower = "checked" Then
                    UseNAT = True
                Else
                    UseNAT = False
                End If
                KNXSetupConnection()
            Case "oConnectionKeepAlive"
                If parts("ConnectionKeepAlive").ToLower = "checked" Then
                    ConnectionKeepAlive = True
                    _ConnectionKeepAlive = True
                Else
                    ConnectionKeepAlive = False
                    _ConnectionKeepAlive = False
                End If
            Case "oRebuildOnSave"
                If parts("RebuildOnSave").ToLower = "checked" Then
                    RebuildOnSave = True
                    _RebuildOnSave = True
                Else
                    RebuildOnSave = False
                    _RebuildOnSave = False
                End If
            Case "oRebuildNow"
                Me.divToUpdate.Add("message", "Updating GroupAddress table")
                GroupAddressTable = BuildGATable()
                Threading.Thread.Sleep(1000)
            Case "oGATypeList"
                Me.divToUpdate.Add("message", "GroupAddress structure changed")
                _GroupAddressStructure = Val(parts("GATypeList"))
                GroupAddressStructure = _GroupAddressStructure
            Case "oCreate"
                PostMessage("Devices are being created ...")

                For i As Integer = 0 To KNXDeviceTypes.Length - 1
                    If KNXCreationCount(i) > 0 Then
                        Select Case KNXDeviceTypes(i)
                            Case "Binary Light"
                                For n As Integer = 1 To KNXCreationCount(i)
                                    CreateBinaryDevice()
                                Next
                            Case "Dimnmer"
                                For n As Integer = 1 To KNXCreationCount(i)
                                    CreateDimmerDevice()
                                Next
                            Case "Temperature Sensor"
                                For n As Integer = 1 To KNXCreationCount(i)
                                    CreateTemperatureDevice()
                                Next
                            Case "Motion Sensor"
                                For n As Integer = 1 To KNXCreationCount(i)
                                    CreateMotionSensorGroup()
                                Next
                            Case "Blind/Curtain"
                                For n As Integer = 1 To KNXCreationCount(i)
                                    CreateBlindCurtainDevice()
                                Next
                            Case "Binary Scene"
                                For n As Integer = 1 To KNXCreationCount(i)
                                    CreateBinarySceneDevice()
                                Next
                            Case "Scene Device"
                                For n As Integer = 1 To KNXCreationCount(i)
                                    CreateSceneDevice()
                                Next
                            Case KNXDeviceTypes(7) ' Thermostat
                                For n As Integer = 1 To KNXCreationCount(i)
                                    CreateThermostatGroup()
                                Next
                        End Select
                    End If
                Next
                'PostMessage("Done!")
            Case "oDebugLevel"
                DebugLevel = parts("DebugLevel")
                PostMessage("")
            Case "oConsoleDebug"
                ConsoleDebugLevel = parts("ConsoleDebug")
                PostMessage("")
            Case "oTimerBasedPoll"
                If parts("TimerBasedPoll").ToLower = "checked" Then
                    _TimerBasedPoll = True
                Else
                    _TimerBasedPoll = False
                End If
                TimerBasedPoll = _TimerBasedPoll
                Try
                    PollingTimer.Stop()
                    PollingTimer.Dispose()
                Catch ex As Exception
                End Try

                Try
                    If _PollingFrequency > 0 Then
                        PollingTimer = New System.Timers.Timer(1000 * _PollingFrequency)
                        PollingTimer.Enabled = True
                        PollingTimer.Start()
                    End If

                Catch ex As Exception
                End Try
                PostMessage("Use of timer based polling updated")
                WriteLog(DebugLog, "Setting TimerBasedPoll to " & _TimerBasedPoll, 5)
            Case "oPollFrequency"
                _PollingFrequency = Val(parts("PollFrequency"))
                PollingFrequency = _PollingFrequency
                Try
                    PollingTimer.Stop()
                    PollingTimer.Dispose()
                Catch ex As Exception
                End Try

                Try
                    If _PollingFrequency > 0 Then
                        PollingTimer = New System.Timers.Timer(1000 * _PollingFrequency)
                        PollingTimer.Enabled = True
                        PollingTimer.Start()
                    End If
                Catch ex As Exception
                End Try
                PostMessage("Polling Frequency Updated")
            Case "oIncludeLocation1"
                _IncludeLocation1 = parts("IncludeLocation1").ToLower = "checked"
                IncludeLocation1 = _IncludeLocation1
                PostMessage("Setting updated")
            Case "oIncludeLocation2"
                _IncludeLocation2 = parts("IncludeLocation2").ToLower = "checked"
                IncludeLocation2 = _IncludeLocation2
                PostMessage("Setting updated")
            Case Else ' Capture the cases that can not be easily spotted from above logic
                If Left(parts("id"), 6) = "oCount" Then
                    Dim Idx As Integer = Val(Right(parts("id"), parts("id").Length - 6))
                    KNXCreationCount(Idx) = Val(parts("Count" & Idx.ToString))
                End If
        End Select

        Return MyBase.postBackProc(page, data, user, userRights)
    End Function

    Public Function GetPagePlugin(ByVal pageName As String, ByVal user As String, ByVal userRights As Integer, ByVal queryString As String) As String
        Dim stb As New StringBuilder
        Dim instancetext As String = ""

        Try
            Me.reset()

            CurrentPage = Me

            ' handle any queries like mode=something
            Dim parts As Collections.Specialized.NameValueCollection = Nothing
            If (queryString <> "") Then
                parts = HttpUtility.ParseQueryString(queryString)
            End If
            If Instance <> "" Then instancetext = " - " & Instance
            'stb.Append(hs.GetPageHeader(pageName, IFACE_NAME & instancetext & " Config", "", "", True, False))

            Me.AddHeader(hs.GetPageHeader(pageName, "Configuration", "", "", False, True))

            'stb.Append("<table border='0' cellpadding='0' cellspacing='0' width='1000'>")
            stb.Append("<table border='0' cellpadding='0' cellspacing='0'>")
            'stb.Append("<tr><td align='center' style='color:#FF0000; font-size:14pt; height:25px;'><strong><div id='message'>&nbsp;</div></strong></td></tr>")

            stb.Append("<tr><td align='center' style='color:#FF0000; font-size:14pt; height:25px;'><strong>")
            stb.Append(clsPageBuilder.DivStart("message", "class='message'") & clsPageBuilder.DivEnd)
            stb.Append("</strong></td></tr>")


            stb.Append("</table>")

            ' a message area for error messages from jquery ajax postback (optional, only needed if using AJAX calls to get data)
            stb.Append(clsPageBuilder.DivStart("errormessage", "class='errormessage'") & clsPageBuilder.DivEnd)

            'Me.RefreshIntervalMilliSeconds = 3000
            'stb.Append(Me.AddAjaxHandlerPost("id=timer", pageName))

            Dim jqtabs As New clsJQuery.jqTabs("tab1id", pageName)
            Dim tab As New clsJQuery.Tab

            tab = New clsJQuery.Tab
            tab.tabTitle = "Connection"
            tab.tabContent = BuildConnectionTab()
            jqtabs.tabs.Add(tab)
            jqtabs.defaultTab = 0

            tab = New clsJQuery.Tab
            tab.tabTitle = "Device Creation"
            tab.tabContent = BuildDeviceCreationTab()
            jqtabs.tabs.Add(tab)
            jqtabs.defaultTab = 0

            tab = New clsJQuery.Tab
            tab.tabTitle = "Group Addresses"
            tab.tabContent = BuildGroupAddressTab()
            jqtabs.tabs.Add(tab)
            jqtabs.defaultTab = 0

            tab = New clsJQuery.Tab
            tab.tabTitle = "Debug"
            tab.tabContent = BuildDebugTab()
            jqtabs.tabs.Add(tab)
            jqtabs.defaultTab = 0

            stb.Append(jqtabs.Build)

            stb.Append(clsPageBuilder.DivEnd)

            ' add the body html to the page
            Me.AddBody(stb.ToString)

            Me.AddFooter(hs.GetPageFooter)
            Me.suppressDefaultFooter = True

            ' return the full page
            Return Me.BuildPage()
        Catch ex As Exception
            'WriteMon("Error", "Building page: " & ex.Message)
            Return "error - " & Err.Description
        End Try
    End Function

    Function BuildConnectionTab() As String
        sTimerBasedPoll = _TimerBasedPoll
        sPollingFrequency = _PollingFrequency

        Dim stb As New StringBuilder

        ' Polling Timer and Event Callback table
        stb.Append("<table border='1' cellpadding='1' cellspacing='0'>")
        stb.Append("<tr>")
        stb.Append("<td class='tablecolumn' width='200'>KNX Tunelling Options:</td>")
        stb.Append("<td class='tablecolumn' width='100'></td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>KNX Interface IP Address</td>")
        stb.Append("<td>" & BuildTextBox("IPAddress", 50, IPAddress) & "</td>")
        stb.Append("</tr>")
        stb.Append("<tr>")
        stb.Append("<td>Port</td>")
        stb.Append("<td>" & BuildTextBox("KNXPort", 50, KNXPort) & "</td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Use NAT</td>")
        stb.Append("<td>" & BuildCheckBox("UseNAT", "", UseNAT, False) & "</td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Keep KNX Bus Connection Alive</td>")
        stb.Append("<td>" & BuildCheckBox("ConnectionKeepAlive", "", ConnectionKeepAlive, False) & "</td>")
        stb.Append("</tr>")

        stb.Append("</table>")
        stb.Append("<br>")

        stb.Append("<table border='1' cellpadding='1' cellspacing='0'>")
        stb.Append("<tr>")
        stb.Append("<td class='tablecolumn' width='200'>Polling:</td>")
        stb.Append("<td class='tablecolumn' width='100'></td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Timer Based Polling</td>")
        stb.Append("<td>" & BuildCheckBox("TimerBasedPoll", "", sTimerBasedPoll, False) & "</td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Polling Frequency (Secs.)</td>")
        stb.Append("<td>" & BuildTextBox("PollFrequency", 50, sPollingFrequency) & "</td>")
        stb.Append("</tr>")

        stb.Append("</table>")
        stb.Append("<br>")

        Return stb.ToString
    End Function

    Function BuildGroupAddressTab() As String
        Dim stb As New StringBuilder

        ' Group Address Structure
        stb.Append("<table border='1' cellpadding='1' cellspacing='0'>")
        stb.Append("<tr>")
        stb.Append("<td class='tablecolumn' width='300'>Group Addresses:</td>")
        stb.Append("<td class='tablecolumn' width='150'></td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>GroupAddress Structure</td>")
        Dim dl As New clsJQuery.jqDropList("GATypeList", Me.PageName, False)
        Dim dlString As String = ""
        dl.items = GATypes
        dl.id = "oGATypeList"
        dl.selectedItemIndex = _GroupAddressStructure - 1 ' index starts at 0
        stb.Append("<td>" & dl.Build() & "</td>")
        stb.Append("</tr>")

        stb.Append("</table>")
        stb.Append("<br>")


        ' Build GroupAddress  table after each DeviceSave table
        stb.Append("<table border='1' cellpadding='1' cellspacing='0'>")
        stb.Append("<tr>")
        stb.Append("<td class='tablecolumn' width='300'>Group Address Rebuild:</td>")
        stb.Append("<td class='tablecolumn' width='150'></td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Build GroupAddress table after each device save?</td>")
        stb.Append("<td>" & BuildCheckBox("RebuildOnSave", "", _RebuildOnSave, False) & "</td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Rebuild Group Address Table now</td>")
        stb.Append("<td>" & BuildButton("RebuildNow", "Rebuild Now", False) & "</td>")
        stb.Append("</tr>")

        stb.Append("</table>")
        stb.Append("<br>")

        Return stb.ToString
    End Function

    Function BuildDeviceCreationTab() As String
        Dim stb As New StringBuilder

        ' Build GroupAddress  table after each DeviceSave table
        stb.Append("<table border='1' cellpadding='1' cellspacing='0'>")
        stb.Append("<tr>")
        stb.Append("<td class='tablecolumn' width='300'>Select devices to be created:</td>")
        stb.Append("<td class='tablecolumn' width='100'></td>")
        stb.Append("</tr>")

        For i = 0 To KNXDeviceTypes.Length - 1
            stb.Append("<tr>")
            stb.Append("<td>" & KNXDeviceTypes(i) & "</td>")
            stb.Append("<td>" & BuildTextBox("Count" & i.ToString, 50, "0", True) & "</td>")
            stb.Append("</tr>")
        Next
        stb.Append("</table>")

        stb.Append("<br>" & BuildButton("Create", "Create", False))

        Return stb.ToString
    End Function

    Function BuildDebugTab() As String
        Dim stb As New StringBuilder

        sDebugLevel = DebugLevel
        sConsole = ConsoleDebugLevel


        stb.Append("<table border='1' cellpadding='1' cellspacing='0'>")
        stb.Append("<tr>")
        stb.Append("<td class='tablecolumn' width='200'>Debug Options:</td>")
        stb.Append("<td class='tablecolumn' width='50'></td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Log File Debug Level:</td>")
        stb.Append("<td>" & BuildTextBox("DebugLevel", 50, sDebugLevel) & "</td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Console Debug Level:</td>")
        stb.Append("<td>" & BuildTextBox("ConsoleDebug", 50, sConsole) & "</td>")
        stb.Append("</tr>")
        stb.Append("</table>")

        Return stb.ToString
    End Function

    Public Function BuildTextBox(ByVal Name As String, ByVal Width As Integer, Optional ByVal Text As String = "", Optional ByVal Rebuilding As Boolean = False) As String
        Dim tb As New clsJQuery.jqTextBox(Name, "", Text, Me.PageName, 20, False)
        Dim TextBox As String = ""
        tb.id = "o" & Name
        If Width > 0 Then tb.width = Width

        TextBox = tb.Build

        If Rebuilding Then
            Me.divToUpdate.Add(Name & "_div", TextBox)
        Else
            TextBox = "<div id='" & Name & "_div'>" & tb.Build & "</div>"
        End If

        Return TextBox
    End Function

    Function BuildButton(ByVal Name As String, Optional ByVal ButtonText As String = "Submit", Optional ByVal Content As String = "", Optional ByVal Rebuilding As Boolean = False) As String
        Dim Button As String
        Dim b As New clsJQuery.jqButton(Name, "", Me.PageName, True)

        b.submitForm = False
        b.id = "o" & Name
        b.label = ButtonText

        Button = b.Build

        If Rebuilding Then
            Me.divToUpdate.Add(Name & "_div", Button)
        Else
            Button = "<div id='" & Name & "_div'>" & Button & "</div>"
        End If
        Return Button
    End Function

    Function BuildCheckBox(ByVal Name As String, Label As String, Checked As Boolean, Optional ByVal Rebuilding As Boolean = False) As String
        Dim CheckBox As String
        Dim cb As New clsJQuery.jqCheckBox(Name, Label, Me.PageName, True, False)
        cb.id = "o" & Name
        cb.checked = Checked
        cb.LabelOnLeft = True
        cb.sliderStyle = True

        CheckBox = cb.Build

        If Rebuilding Then
            Me.divToUpdate.Add(Name & "_div", CheckBox)
        Else
            CheckBox = "<div id='" & Name & "_div'>" & CheckBox & "</div>"
        End If
        Return CheckBox
    End Function

    Sub PostMessage(ByVal sMessage As String)
        Me.divToUpdate.Add("message", sMessage)
        'Me.pageCommands.Add("starttimer", "")
        'TimerEnabled = True
    End Sub

End Class

